package com.beneficios.beneficiosuom.datos

// NOTICIA   ------------------------------------------------------
data class NoticiaBD(
    var ID: Int,
    var titulo: String,
    var contenido: String,
    var fechaDeCreacion: String,
    var categoria: String,
    var link: String,
    var imagen: String
) {
    constructor(): this(0,"","","","","","")
}
