package com.beneficios.beneficiosuom.interfaz

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Alignment.Companion.End
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat.startActivity
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.beneficios.beneficiosuom.R
import com.beneficios.beneficiosuom.datos.BeneficioBD
import com.beneficios.beneficiosuom.datos.SubBeneficioBD

fun devolverListaID(
    listaB: List<SubBeneficioBD>,
    IDOrigenLista: Int
): MutableList<SubBeneficioBD> {
    val listaNew: MutableList<SubBeneficioBD> = mutableListOf()

    for (SubBeneficioBD in listaB) {
        if (IDOrigenLista == SubBeneficioBD.IDOrigen) {
            listaNew.add(SubBeneficioBD)
        }
    }
    return listaNew
}

@Composable
fun tomarObjetoDeLista(id: Int?, listaBeneficio: List<BeneficioBD>): BeneficioBD {

    var elObjeto = BeneficioBD(
        0,
        "Nada",
        "Nada",
        "Nada",
        "Nada",
        "Nada",
        "Nada",
        "",
        "Nada",
        false,
        false
    )

    for (BeneficioBD in listaBeneficio) {
        if (id == BeneficioBD.ID) {
            elObjeto = BeneficioBD
        }
    }
    return elObjeto
}

@Composable
fun Detalle(
    navController: NavController,
    listaCompleta: List<BeneficioBD>,
    numero: Int?,
    listaSub: List<SubBeneficioBD>,
    mapaNombreImagen: Map<String, String>,
    colorLetra:Color, fuenteLetra: androidx.compose.ui.text.font.FontFamily, colorFondo:Color
) {

    val objeto: BeneficioBD = tomarObjetoDeLista(numero, listaCompleta)
    val subBeneficios: List<SubBeneficioBD> = devolverListaID(listaSub, objeto.ID)

    val context = LocalContext.current
    val mapIntent: Intent =
        Uri
            .parse("geo:0,0?q=${objeto.lugar.toString()+" Rio Grande"}")
            .let { location ->
                Intent(Intent.ACTION_VIEW, location)
            }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight()
            .verticalScroll(rememberScrollState())
    ) {
        Spacer(modifier = Modifier.height(75.dp))

        Text(
            text = objeto.lugar,
            color = Color.Black,
            fontFamily = fuenteLetra,
            textAlign = TextAlign.Center,
            fontSize = 30.sp,
            modifier = Modifier
        )

        AsyncImage(
            model = mapaNombreImagen.get(objeto.imagen),
            contentDescription = null,
            error = painterResource(id = R.drawable.imagenerror),
            placeholder = painterResource(id = R.drawable.imagencarga),
            contentScale = ContentScale.FillWidth,
            modifier = Modifier
                .padding(top = 15.dp, bottom = 15.dp)
                .fillMaxWidth(0.9f)
        )

        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Descripcion",
                fontFamily = fuenteLetra,
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(start = 25.dp)
            )

            Image(
                painter = painterResource(R.drawable.maps),
                contentDescription = null,
                Modifier
                    .wrapContentWidth(End)
                    .padding(end = 25.dp)
                    .size(20.dp)
                    .clickable { // Map point based on address
                        startActivity(context, mapIntent, null)
                    }
            )
        }

        Spacer(modifier = Modifier.height(5.dp))

        // Fondo negro y letras blancas
        Column(
            horizontalAlignment = CenterHorizontally,
            modifier = Modifier
                .padding(start = 10.dp, end = 10.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(color = colorFondo)
                .fillMaxWidth()
        ) {

            Text(
                text = (objeto.descripcionCompleta),
                fontFamily = fuenteLetra,
                color = colorLetra,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(start = 10.dp, top = 10.dp, end = 10.dp, bottom = 2.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                horizontalArrangement = Arrangement.SpaceAround, modifier = Modifier.fillMaxWidth()
            ) {

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .padding(
                            start = 20.dp,
                            top = 8.dp,
                            end = 0.dp,
                            bottom = 8.dp
                        )
                        .fillMaxWidth(0.4f)
                ) {
                    Text(
                        text = "Horarios",
                        fontFamily = fuenteLetra,
                        color = colorLetra,
                        fontSize = 15.sp,
                        textAlign = TextAlign.Center,
                        textDecoration = TextDecoration.Underline
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = (objeto.horario.toString()),
                        fontFamily = fuenteLetra,
                        color = colorLetra,
                        fontSize = 15.sp,
                        textAlign = TextAlign.Center,
                    )
                }

                Spacer(modifier = Modifier.width(50.dp))

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .padding(
                            start = 5.dp,
                            top = 8.dp,
                            end = 0.dp,
                            bottom = 8.dp
                        )
                        .fillMaxWidth(1f)
                ) {
                    Text(
                        text = "Telefonos",
                        fontFamily = fuenteLetra,
                        color = colorLetra,
                        fontSize = 15.sp,
                        textAlign = TextAlign.Center,
                        textDecoration = TextDecoration.Underline
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Icono de telefono y telefono
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Image(
                            painter = painterResource(R.drawable.telefono_blanco),
                            contentDescription = null,
                            Modifier
                                .wrapContentWidth(Alignment.Start)
                                .size(20.dp)
                        )

                        Text(
                            text = (objeto.telefono),
                            fontFamily = fuenteLetra,
                            color = colorLetra,
                            textAlign = TextAlign.Center,
                            fontSize = 15.sp,
                            modifier = Modifier.padding(start = 10.dp)
                        )
                    }
                }

            }//Fin Row

            Text(
                text = "Direccion",
                fontFamily = fuenteLetra,
                color = colorLetra,
                textDecoration = TextDecoration.Underline,
                textAlign = TextAlign.Center,
                modifier = Modifier
            )

            Text(
                text = (objeto.ubicacion),
                fontFamily = fuenteLetra,
                color = colorLetra,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(start = 4.dp, top = 10.dp, end = 4.dp, bottom = 10.dp)
            )
        }

        Spacer(modifier = Modifier.height(15.dp))

        // Beneficios -----------------------------------------------------------------------------

        if (objeto.descuentoSINO) {

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Descuentos",
                fontFamily = fuenteLetra,
                color = Color.Black,
                fontSize = 24.sp,
                textDecoration = TextDecoration.Underline,
                textAlign = TextAlign.Center,
                modifier = Modifier.wrapContentWidth(Alignment.CenterHorizontally)
            )

            Spacer(modifier = Modifier.height(4.dp))

            for (sub in subBeneficios) {

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .padding(
                            start = 10.dp, top = 2.dp, end = 15.dp, bottom = 2.dp
                        )
                        .size(width = 500.dp, height = 80.dp)
                        .wrapContentWidth(CenterHorizontally)
                ) {

                    Column(
                        modifier = Modifier
                            .padding(4.dp, end = 10.dp)
                            .clip(RoundedCornerShape(15.dp))
                            .background(color = colorFondo)
                    ) {
                        Text(
                            text = sub.porcentaje.toString() + " %",
                            fontFamily = fuenteLetra,
                            color = colorLetra,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .padding(15.dp)
                        )
                    }

                    Column(
                        modifier = Modifier
                            .padding(4.dp)
                            .clip(RoundedCornerShape(15.dp))
                            .background(color = colorFondo)
                    ) {
                        Text(
                            text = sub.descripcion,
                            fontFamily = fuenteLetra,
                            color = colorLetra,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .padding(15.dp)

                        )
                    }
                }
            }
        }

        // Tarifa -----------------------------------------------------------------------------

        if (objeto.tarifaSINO) {

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Tarifas",
                fontFamily = fuenteLetra,
                color = colorLetra,
                fontSize = 24.sp,
                textDecoration = TextDecoration.Underline,
                textAlign = TextAlign.Center,
                modifier = Modifier.wrapContentWidth(Alignment.CenterHorizontally)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Column(
                horizontalAlignment = CenterHorizontally,
                modifier = Modifier
                    .padding(10.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .background(color = colorFondo)
                    .fillMaxWidth()
            ) {

                Text(
                    text = ("Para ver las tarifas dirigirse a la pagina web de UOM ARGENTINA:\n"),
                    fontFamily = fuenteLetra,
                    color = colorLetra,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(
                        start = 10.dp, top = 10.dp, end = 10.dp, bottom = 0.dp
                    )
                )

                val link = remember { Intent(Intent.ACTION_VIEW, Uri.parse("https://www.uom.org.ar/site/turismo/turismo-tarifas-hoteles/")) }

                Text(
                    text = ("https://www.uom.org.ar/site/turismo/turismo-tarifas-hoteles/\n"),
                    color = Color.Blue,
                    fontFamily = fuenteLetra,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.clickable { context.startActivity(link) }
                )
                Text(
                    text = ("Al momento del ingreso al hotel, el Titular y su grupo familiar deberán presentar, sin excepciones: \n" +
                            " - Carnet de Afiliado\n" +
                            " - DNI\n" +
                            " - Recibo de Sueldo\n" +
                            " - Constancia de pago del depósito (de haberse realizado) sin excepción\n\n" +
                            "Por dudas o consultas, diríjase a la Seccional que le corresponde para asesoría."),
                    fontFamily = fuenteLetra,
                    color = colorLetra,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(
                        start = 10.dp, top = 0.dp, end = 10.dp, bottom = 10.dp
                    )
                )
            }
        }

    }// Fin colum principal

    Toolbar2(titulo = objeto.categoria, fondo = Color.White, letra = Color.Black, fuente = fuenteLetra,
        //Back2 = devolverImagenBD("ImagenesIconos/Back2.png"), Back1 = devolverImagenBD("ImagenesIconos/Back1.png"), Icono2 = devolverImagenBD("ImagenesIconos/iconoUOM2.png"), Icono1 = devolverImagenBD("ImagenesIconos/iconoUOM1.png")
        navController)

}