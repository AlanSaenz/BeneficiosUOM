package com.beneficios.beneficiosuom.datos

// NUMEROS UTILES   ------------------------------------------------------
data class NumerosUtilesBD(
    var ID: Int,
    var nombre: String,
    var telefono: String?,
    var direccion: String?,
) {
    constructor() : this(0,"","","")
}
