package com.beneficios.beneficiosuom.interfaz

import android.annotation.SuppressLint
import android.content.ContentValues
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import com.beneficios.beneficiosuom.R
import com.beneficios.beneficiosuom.datos.BeneficiarioBD
import com.beneficios.beneficiosuom.datos.BeneficioBD
import com.beneficios.beneficiosuom.navegacion.PantallaApp
import kotlinx.coroutines.tasks.await


@SuppressLint("SuspiciousIndentation")
suspend fun devolverImagenBD(url: String): String {
    Log.d(ContentValues.TAG, "ENTRO A LA FUNCION PARA CARGA DE IMAGEN BD")

    var imagen = ""
    val URL = url
    val RefIMG = storageRef.child(URL)

    RefIMG.downloadUrl.addOnSuccessListener {
        imagen = it.toString()
        Log.d(ContentValues.TAG, "IMAGEN DE FUNCION PROCESADO ♥ url = $url | imagen =  $imagen")
    }.addOnFailureListener { exception ->
        Log.d(ContentValues.TAG, "ERROR CARGA DE IMAGEN DE FUNCION - $exception - URL = $URL")
    }.await()

    return imagen
}

// , Back2 = devolverImagenBD("ImagenesIconos/Back2.png"), Back1 = devolverImagenBD("ImagenesIconos/Back1.png"), Icono2 = devolverImagenBD("ImagenesIconos/iconoUOM2.png"), Icono1 = devolverImagenBD("ImagenesIconos/iconoUOM1.png")
// -----------------------------------------------------------------------------------------------

@Composable
fun Toolbar(titulo: String, fuente: FontFamily) {
    TopAppBar(backgroundColor = Color.White) {

        Text(
            text = titulo,
            color = Color.Black,
            textAlign = TextAlign.Center,
            fontSize = 24.sp,
            fontFamily = fuente,
            fontWeight = FontWeight.Black,
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth()
                .padding(top = 10.dp)
        )
    }
}

// -----------------------------------------------------------------------------------------------

@Composable
fun ToolbarInicio(
    titulo: String,
    fuente: FontFamily,
    usuario: BeneficiarioBD,
    navController: NavController
) {
    TopAppBar(backgroundColor = Color.White) {

        Text(
            text = titulo,
            color = Color.Black,
            textAlign = TextAlign.Center,
            fontSize = 24.sp,
            fontFamily = fuente,
            fontWeight = FontWeight.Black,
            modifier = Modifier
                .padding(vertical = 10.dp, horizontal = 1.dp)
                .fillMaxWidth(0.85f)
        )

        if (usuario.notificaciones.isEmpty()) {

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
            ) {

                Image(
                    painter = painterResource(id = R.drawable.notificacionicono),
                    contentDescription = null,
                    contentScale = ContentScale.FillHeight,
                    modifier = Modifier
                        .clickable { navController.navigate(route = PantallaApp.Notificacion.ruta) }
                        .fillMaxHeight(0.7f)
                )

                Text(
                    text = "Notificacion",
                    textAlign = TextAlign.Center,
                    fontSize = 11.sp,
                    color = Color.Black,
                    fontFamily = fuente,
                    modifier = Modifier
                )

            }

        } else if (!usuario.notificaciones.isEmpty()) {

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
            ) {

                Image(
                    painter = painterResource(id = R.drawable.notificacioniconorojo),
                    contentDescription = null,
                    contentScale = ContentScale.FillHeight,
                    modifier = Modifier
                        .clickable { navController.navigate(route = PantallaApp.Notificacion.ruta) }
                        .fillMaxHeight(0.7f)
                )

                Text(
                    text = "Notificacion",
                    textAlign = TextAlign.Center,
                    fontSize = 11.sp,
                    color = Color.Black,
                    fontFamily = fuente,
                    modifier = Modifier
                )

            }

        }

    }
}

@Composable
fun Toolbar2(
    titulo: String?,
    fondo: Color,
    letra: Color,
    fuente: FontFamily,
    navController: NavController
) {

    val Back2State = remember { mutableStateOf("") }
    val Back1State = remember { mutableStateOf("") }
    val Icono2State = remember { mutableStateOf("") }
    val Icono1State = remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        Back2State.value = devolverImagenBD("ImagenesIconos/Back2.png")
        Back1State.value = devolverImagenBD("ImagenesIconos/Back1.png")
        Icono2State.value = devolverImagenBD("ImagenesIconos/iconoUOM2.png")
        Icono1State.value = devolverImagenBD("ImagenesIconos/iconoUOM1.png")
    }

    val Back2 = Back2State.value
    val Back1 = Back1State.value
    val Icono2 = Icono2State.value
    val Icono1 = Icono1State.value

    TopAppBar(backgroundColor = fondo) {

        // Boton BACK, Izquierda, dependiendo si es Blanco o Negro
        if (fondo == Color.Black) {

            AsyncImage(
                model = Back2,
                contentDescription = null,
                error = painterResource(id = R.drawable.iconoback1),
                //error = painterResource(id = R.drawable.imagenerror),
                //error = painterResource(id = R.drawable.imagencarga),
                placeholder = painterResource(id = R.drawable.imagencarga),
                contentScale = ContentScale.FillHeight,
                modifier = Modifier
                    .clickable { navController.popBackStack() }
                    .padding(vertical = 10.dp, horizontal = 5.dp)
            )

            /*Image(
                painter = painterResource(id = R.drawable.iconoback1),
                contentDescription = null,
                contentScale = ContentScale.FillHeight,
                modifier = Modifier
                    .clickable { navController.popBackStack() }
                    .padding(vertical = 10.dp, horizontal = 5.dp)
            )
             */

        } else if (fondo == Color.White) {

            AsyncImage(
                model = Back1,
                contentDescription = null,
                error = painterResource(id = R.drawable.iconoback2),
                //error = painterResource(id = R.drawable.imagenerror),
                //error = painterResource(id = R.drawable.imagencarga),
                placeholder = painterResource(id = R.drawable.imagencarga),
                contentScale = ContentScale.FillHeight,
                modifier = Modifier
                    .clickable { navController.popBackStack() }
                    .padding(vertical = 10.dp, horizontal = 5.dp)
            )

            /*Image(
                painter = painterResource(id = R.drawable.iconoback2),
                contentDescription = null,
                contentScale = ContentScale.FillHeight,
                modifier = Modifier
                    .clickable { navController.popBackStack() }
                    .padding(vertical = 10.dp, horizontal = 5.dp)
            )
             */
        }

        // titulo de toolbar, centro, dependiendo si es Blanco o Negro
        if (titulo != null) {
            Text(
                text = titulo,
                color = letra,
                textAlign = TextAlign.Center,
                fontSize = 25.sp,
                fontFamily = fuente,
                modifier = Modifier
                    .padding(vertical = 10.dp, horizontal = 15.dp)
                    .fillMaxWidth(0.84f)
            )
        }

        // Icono UOM, derecha, dependiendo si es Blanco o Negro
        if (fondo == Color.Black) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
            ) {

                AsyncImage(
                    model = Icono2,
                    contentDescription = null,
                    error = painterResource(id = R.drawable.icono_uom_invertido),
                    //error = painterResource(id = R.drawable.imagenerror),
                    //error = painterResource(id = R.drawable.imagencarga),
                    placeholder = painterResource(id = R.drawable.imagencarga),
                    contentScale = ContentScale.FillHeight,
                    modifier = Modifier
                        .clickable { navController.navigate(route = PantallaApp.Inicio.ruta) }
                        .fillMaxHeight(0.8f)
                )

                /*Image(
                    painter = painterResource(id = R.drawable.icono_uom_invertido),
                    contentDescription = null,
                    contentScale = ContentScale.FillHeight,
                    modifier = Modifier
                        .clickable { navController.navigate(route = PantallaApp.Inicio.ruta) }
                        .fillMaxHeight(0.8f)
                )
                 */

                Text(
                    text = "INICIO",
                    textAlign = TextAlign.Center,
                    fontSize = 10.sp,
                    color = Color.White,
                    fontFamily = fuente,
                    modifier = Modifier
                )
            }

        } else if (fondo == Color.White) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
            ) {

                AsyncImage(
                    model = Icono1,
                    contentDescription = null,
                    error = painterResource(id = R.drawable.icono_uom),
                    //error = painterResource(id = R.drawable.imagenerror),
                    //error = painterResource(id = R.drawable.imagencarga),
                    placeholder = painterResource(id = R.drawable.imagencarga),
                    contentScale = ContentScale.FillHeight,
                    modifier = Modifier
                        .clickable {
                            navController.popBackStack()
                            navController.navigate(route = PantallaApp.Inicio.ruta)
                        }
                        .fillMaxHeight(0.8f)
                )

                /*Image(
                    painter = painterResource(id = R.drawable.icono_uom),
                    contentDescription = null,
                    contentScale = ContentScale.FillHeight,
                    modifier = Modifier
                        .clickable { navController.navigate(route = PantallaApp.Inicio.ruta) }
                        .fillMaxHeight(0.8f)
                )
                 */

                Text(
                    text = "INICIO",
                    textAlign = TextAlign.Center,
                    fontSize = 10.sp,
                    color = Color.Black,
                    fontFamily = fuente,
                    modifier = Modifier
                )
            }
        }
    }
}

@Composable
fun Toolbar3(
    titulo: String?,
    fondo: Color,
    letra: Color,
    fuente: FontFamily,
    navController: NavController
) {

    val Back2State = remember { mutableStateOf("") }
    val Back1State = remember { mutableStateOf("") }
    val Icono2State = remember { mutableStateOf("") }
    val Icono1State = remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        Back2State.value = devolverImagenBD("ImagenesIconos/Back2.png")
        Back1State.value = devolverImagenBD("ImagenesIconos/Back1.png")
        Icono2State.value = devolverImagenBD("ImagenesIconos/iconoUOM2.png")
        Icono1State.value = devolverImagenBD("ImagenesIconos/iconoUOM1.png")
    }


    val Back2 = Back2State.value
    val Back1 = Back1State.value
    val Icono2 = Icono2State.value
    val Icono1 = Icono1State.value

    //var Back2 = devolverImagenBD("ImagenesIconos/Back2.png")
    //var Back1 = devolverImagenBD("ImagenesIconos/Back1.png")
    //var Icono2 = devolverImagenBD("ImagenesIconos/iconoUOM2.png")
    //var Icono1 = devolverImagenBD("ImagenesIconos/iconoUOM1.png")

    TopAppBar(backgroundColor = fondo) {

        // Boton BACK, Izquierda, dependiendo si es Blanco o Negro
        if (fondo == Color.Black) {


            AsyncImage(
                model = Back2,
                contentDescription = null,
                error = painterResource(id = R.drawable.iconoback1),
                //error = painterResource(id = R.drawable.imagenerror),
                //error = painterResource(id = R.drawable.imagencarga),
                placeholder = painterResource(id = R.drawable.imagencarga),
                contentScale = ContentScale.FillHeight,
                modifier = Modifier
                    .clickable { navController.popBackStack() }
                    .padding(vertical = 10.dp, horizontal = 5.dp)
            )

            /*
            Image(
                painter = painterResource(id = R.drawable.iconoback1),
                contentDescription = null,
                contentScale = ContentScale.FillHeight,
                modifier = Modifier
                    .clickable { navController.popBackStack() }
                    .padding(vertical = 10.dp, horizontal = 5.dp)
            )
             */

        } else if (fondo == Color.White) {

            AsyncImage(
                model = Back1,
                contentDescription = null,
                error = painterResource(id = R.drawable.iconoback2),
                //error = painterResource(id = R.drawable.imagenerror),
                //error = painterResource(id = R.drawable.imagencarga),
                placeholder = painterResource(id = R.drawable.imagencarga),
                contentScale = ContentScale.FillHeight,
                modifier = Modifier
                    .clickable { navController.popBackStack() }
                    .padding(vertical = 10.dp, horizontal = 5.dp)
            )

            /*
            Image(
                painter = painterResource(id = R.drawable.iconoback2),
                contentDescription = null,
                contentScale = ContentScale.FillHeight,
                modifier = Modifier
                    .clickable { navController.popBackStack() }
                    .padding(vertical = 10.dp, horizontal = 5.dp)
            )
             */
        }

        // titulo de toolbar, centro, dependiendo si es Blanco o Negro
        if (titulo != null) {
            Text(
                text = titulo,
                color = letra,
                textAlign = TextAlign.Center,
                fontSize = 25.sp,
                fontFamily = fuente,
                modifier = Modifier
                    .padding(vertical = 10.dp, horizontal = 15.dp)
                    .fillMaxWidth(0.83f)
            )
        }

        // Icono UOM, derecha, dependiendo si es Blanco o Negro
        if (fondo == Color.Black) {

            AsyncImage(
                model = Icono2,
                contentDescription = null,
                error = painterResource(id = R.drawable.icono_uom_invertido),
                //error = painterResource(id = R.drawable.imagenerror),
                //error = painterResource(id = R.drawable.imagencarga),
                placeholder = painterResource(id = R.drawable.imagencarga),
                contentScale = ContentScale.FillHeight,
                modifier = Modifier
                    .clickable { navController.navigate(route = PantallaApp.Inicio.ruta) }
                    .fillMaxHeight(0.8f)
            )
            /*
            Image(
                painter = painterResource(id = R.drawable.icono_uom_invertido),
                contentDescription = null,
                contentScale = ContentScale.FillHeight,
                modifier = Modifier

            )
             */
        } else if (fondo == Color.White) {

            AsyncImage(
                model = Icono1,
                contentDescription = null,
                error = painterResource(id = R.drawable.icono_uom),
                //error = painterResource(id = R.drawable.imagenerror),
                //error = painterResource(id = R.drawable.imagencarga),
                placeholder = painterResource(id = R.drawable.imagencarga),
                contentScale = ContentScale.FillHeight,
                modifier = Modifier
                    .clickable { navController.navigate(route = PantallaApp.Inicio.ruta) }
                    .fillMaxHeight(0.8f)
            )

            /*
            Image(
                painter = painterResource(id = R.drawable.icono_uom),
                contentDescription = null,
                contentScale = ContentScale.FillHeight,
                modifier = Modifier
            )
             */
        }
    }
}

@Composable
fun ToolbarNumerosUtiles(
    titulo: String?,
    fondo: Color,
    letra: Color,
    fuente: FontFamily,
    navController: NavController
) {
    TopAppBar(backgroundColor = fondo, modifier = Modifier.height(60.dp)) {

        // Boton BACK, Izquierda, dependiendo si es Blanco o Negro
        Image(
            painter = painterResource(id = R.drawable.iconoback1),
            contentDescription = null,
            contentScale = ContentScale.FillHeight,
            modifier = Modifier
                .clickable { navController.popBackStack() }
                .padding(vertical = 10.dp, horizontal = 5.dp)
        )

        // titulo de toolbar, centro, dependiendo si es Blanco o Negro
        if (titulo != null) {
            Text(
                text = titulo,
                color = letra,
                textAlign = TextAlign.Center,
                fontSize = 28.sp,
                fontFamily = fuente,
                modifier = Modifier
                    .padding(start = 0.dp, end = 0.dp, top = 10.dp, bottom = 10.dp)
                    .fillMaxWidth(0.82f)
            )
        }

        // Icono UOM, derecha, dependiendo si es Blanco o Negro
        Image(
            painter = painterResource(id = R.drawable.telefono_blanco),
            contentDescription = null,
            contentScale = ContentScale.FillHeight,
            modifier = Modifier.padding(start = 0.dp, end = 5.dp, top = 8.dp, bottom = 8.dp)
        )
    }
}

@Composable
fun ToolbarCredencial(
    titulo: String?,
    fondo: Color,
    letra: Color,
    fuente: FontFamily,
    navController: NavController
) {
    TopAppBar(backgroundColor = fondo, modifier = Modifier.height(60.dp)) {

        // Boton BACK, Izquierda, dependiendo si es Blanco o Negro
        Image(
            painter = painterResource(id = R.drawable.iconoback1),
            contentDescription = null,
            contentScale = ContentScale.FillHeight,
            modifier = Modifier
                .clickable { navController.popBackStack() }
                .padding(vertical = 10.dp, horizontal = 5.dp)
        )

        // titulo de toolbar, centro, dependiendo si es Blanco o Negro
        if (titulo != null) {
            Text(
                text = titulo,
                color = letra,
                textAlign = TextAlign.Center,
                fontSize = 28.sp,
                fontFamily = fuente,
                modifier = Modifier
                    .padding(start = 0.dp, end = 0.dp, top = 10.dp, bottom = 10.dp)
                    .fillMaxWidth(0.82f)
            )
        }

        // Icono UOM, derecha, dependiendo si es Blanco o Negro
        Image(
            painter = painterResource(id = R.drawable.tarjeta_blanco),
            contentDescription = null,
            contentScale = ContentScale.FillHeight,
            modifier = Modifier.padding(start = 0.dp, end = 5.dp, top = 8.dp, bottom = 8.dp)
        )
    }
}