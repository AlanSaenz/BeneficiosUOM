package com.beneficios.beneficiosuom.interfaz

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import androidx.compose.material.Text
import androidx.compose.runtime.*

@Composable
fun CheckInternetConnection(context: Context) {

    val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

        val networkCapabilities =
            connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)

        if (networkCapabilities == null ||
            !networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) &&
            !networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        ) {

            Text(text = "No tienes conexión a internet")
        }
    } else {
        val networkInfo = connectivityManager.activeNetworkInfo
        if (networkInfo == null || !networkInfo.isConnected) {

            Text(text = "No tienes conexión a internet")
        }
    }

}
