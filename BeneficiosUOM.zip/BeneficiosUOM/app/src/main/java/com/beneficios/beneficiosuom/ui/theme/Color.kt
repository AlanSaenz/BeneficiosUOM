package com.beneficios.beneficiosuom.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)
val naranjaAPP = Color(0xFFFF5722)

fun saberColor(textoConfig: String):Color{

    if (textoConfig == "rojo"){
        return Color.Red
    }else if(textoConfig == "azul"){
        return Color.Blue
    }else if(textoConfig == "negro"){
        return Color.Black
    }else if(textoConfig == "blanco"){
        return Color.White
    }else if(textoConfig == "cyan"){
        return Color.Cyan
    }else if(textoConfig == "gris"){
        return Color.Gray
    }else if(textoConfig == "grisO"){
        return Color.DarkGray
    }else if(textoConfig == "grisC"){
        return Color.LightGray
    }else if(textoConfig == "verde"){
        return Color.Green
    }else if(textoConfig == "magenta"){
        return Color.Magenta
    }else if(textoConfig == "amarillo"){
        return Color.Yellow
    }else if(textoConfig == "transparente"){
        return Color.Transparent

    }else {
        return Color.Black
    }
}

fun saberColor2(textoConfig: String):Color{

    if (textoConfig == "rojo"){
        return Color.Red
    }else if(textoConfig == "azul"){
        return Color.Blue
    }else if(textoConfig == "negro"){
        return Color.Black
    }else if(textoConfig == "blanco"){
        return Color.White
    }else if(textoConfig == "cyan"){
        return Color.Cyan
    }else if(textoConfig == "gris"){
        return Color.Gray
    }else if(textoConfig == "grisO"){
        return Color.DarkGray
    }else if(textoConfig == "grisC"){
        return Color.LightGray
    }else if(textoConfig == "verde"){
        return Color.Green
    }else if(textoConfig == "magenta"){
        return Color.Magenta
    }else if(textoConfig == "amarillo"){
        return Color.Yellow
    }else if(textoConfig == "transparente"){
        return Color.Transparent

    }else {
        return Color.White
    }
}