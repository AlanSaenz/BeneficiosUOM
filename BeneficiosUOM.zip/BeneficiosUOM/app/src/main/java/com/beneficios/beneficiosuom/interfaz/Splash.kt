package com.beneficios.beneficiosuom.interfaz

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.beneficios.beneficiosuom.R
import com.beneficios.beneficiosuom.navegacion.PantallaApp
import com.beneficios.beneficiosuom.ui.theme.BeneficiosUOMTheme
import com.beneficios.beneficiosuom.ui.theme.roboto
import kotlinx.coroutines.delay

@Composable
fun splashPantalla(navController: NavController) {
    val context = LocalContext.current

    LaunchedEffect(key1 = true) {
        delay(2700) //3000
        navController.popBackStack()
        navController.navigate(PantallaApp.DNI.ruta) // Ruta despues del SPLASH
    }

    CheckInternetConnection(context)
    splash()
}

@Composable
fun splash() {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color.White
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(R.drawable.bandera40a_os_sinfondo),
                contentDescription = "Bandera UOM",
                modifier = Modifier
                    .fillMaxWidth()
                    .background(color = Color.White)
                    .padding(bottom = 5.dp),
                contentScale = ContentScale.Crop
            )

            Image(
                painter = painterResource(R.drawable.bandera2_sinfondo),
                contentDescription = "Seccional UOM",
                modifier = Modifier
                    .size(width = 180.dp, height = 80.dp)
                    .background(color = Color.White)
                    .padding(bottom = 5.dp),
                contentScale = ContentScale.Fit
            )
        }

        Spacer(modifier = Modifier.height(15.dp))

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Bottom,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
        ) {

            Text(
                text = "Desarrollado por \n Alan Saenz Y Lucia Narvaez",
                fontFamily = roboto,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(15.dp))

            /*
            Image(
                painter = painterResource(R.drawable.firebase2),
                contentDescription = "Firebase",
                contentScale = ContentScale.FillWidth
            )
             */

        }

    }

}

@Composable
@Preview
fun previewSplash() {
    BeneficiosUOMTheme {
        Surface(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth()
                .fillMaxSize(),
            color = Color.White
        ) {
            splash()
        }
    }
}
