package com.beneficios.beneficiosuom.ui.theme

import androidx.compose.material.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.beneficios.beneficiosuom.R

fun saberFuente(Origen:String):FontFamily{

    if (Origen == "roboto"){
        var fuenteLetra = FontFamily(Font(R.font.roboto_italic, FontWeight.Normal, FontStyle.Italic))
        return  fuenteLetra

    }else if (Origen == "marmelad"){
        var fuenteLetra = FontFamily(Font(R.font.marmelad_regular, FontWeight.Normal))
        return  fuenteLetra

    }else {
        var fuenteLetra = FontFamily(Font(R.font.roboto_italic, FontWeight.Normal, FontStyle.Italic))
        return fuenteLetra
    }
}

//Fuentes normales, DEFINIR MAS FUENTES

val roboto = FontFamily(
    Font(R.font.roboto_italic, FontWeight.Normal, FontStyle.Italic)
    )

val marmelad = FontFamily(
    Font(R.font.marmelad_regular, FontWeight.Normal)
)



// Set of Material typography styles to start with
val Typography = Typography(
    body1 = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp
    )

    /* Other default text styles to override
    button = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.W500,
        fontSize = 14.sp
    ),
    caption = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp
    )
    */
)