package com.beneficios.beneficiosuom.interfaz

import androidx.compose.animation.core.withInfiniteAnimationFrameMillis
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.BottomCenter
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.beneficios.beneficiosuom.R
import com.beneficios.beneficiosuom.datos.BeneficioBD
import com.beneficios.beneficiosuom.datos.NoticiaBD
import com.beneficios.beneficiosuom.navegacion.PantallaApp
import com.beneficios.beneficiosuom.ui.theme.roboto

@Composable
fun Prensa(
    navController: NavController,
    listaNoticia: List<NoticiaBD>,
    mapaNombreImagen2: Map<String, String>,
    imgFondo: String,
    colorLetra:Color, colorMarco:Color, fuenteLetra: androidx.compose.ui.text.font.FontFamily, colorFondo:Color
) {

    val fondoEngranaje = painterResource(id = R.drawable.fondonewfinal)

    AsyncImage(
        model = imgFondo,
        contentDescription = null,
        error = fondoEngranaje,
        placeholder = painterResource(id = R.drawable.imagencarga),
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(),
        contentScale = ContentScale.FillWidth
    )

    /*
    Image(
        painter = fondoEngranaje,
        contentDescription = null,
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(),
        contentScale = ContentScale.FillWidth
    )
     */

    LazyColumn(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight()
    ) {

        item { Spacer(modifier = Modifier.height(54.dp)) }

        item {
            seccional(
                "Gremio",
                lista = tomarListaNoticia(listaNoticia, "Gremio"),
                navController,
                mapaNombreImagen2,
                colorFondo = colorFondo, colorLetra = colorLetra, fuenteLetra = fuenteLetra, colorMarco = colorMarco
            )
        }

        item {
            seccional(
                "Obra social",
                lista = tomarListaNoticia(listaNoticia, "Obra social"),
                navController,
                mapaNombreImagen2,
                colorFondo = colorFondo, colorLetra = colorLetra, fuenteLetra = fuenteLetra, colorMarco = colorMarco
            )
        }

        item {
            seccional(
                "Varios",
                lista = tomarListaNoticia(listaNoticia, "Varios"),
                navController,
                mapaNombreImagen2,
                colorFondo = colorFondo, colorLetra = colorLetra, fuenteLetra = fuenteLetra, colorMarco = colorMarco
            )
        }
    }
    Toolbar3(titulo = "Prensa y difusión", fondo = Color.White, letra = Color.Black, fuente = fuenteLetra,
        //Back2 = devolverImagenBD("ImagenesIconos/Back2.png"), Back1 = devolverImagenBD("ImagenesIconos/Back1.png"), Icono2 = devolverImagenBD("ImagenesIconos/iconoUOM2.png"), Icono1 = devolverImagenBD("ImagenesIconos/iconoUOM1.png"),
        navController)
}

@Composable
public fun tomarListaNoticia(listaCompleta: List<NoticiaBD>, categoria: String?): List<NoticiaBD> {
    val newList: MutableList<NoticiaBD> = mutableListOf()

    for (NoticiaBD in listaCompleta) {
        if (categoria == NoticiaBD.categoria) {
            newList.add(NoticiaBD)
        }
    }
    return newList
}

@Composable
fun seccional(
    titulo: String,
    lista: List<NoticiaBD>,
    navController: NavController,
    mapaNombreImagen2: Map<String, String>,
    fuenteLetra: FontFamily,
    colorLetra: Color,
    colorFondo: Color,
    colorMarco: Color
) {

    Column(
        modifier = Modifier
            .size(width = 1000.dp, height = 250.dp)
            .fillMaxWidth()
    ) {

        Text(
            text = titulo,
            fontFamily = fuenteLetra,
            color = colorLetra,
            textAlign = TextAlign.Start,
            fontSize = 20.sp,
            modifier = Modifier
                .background(colorFondo)
                .fillMaxWidth()
                .padding(10.dp)
                .wrapContentWidth(Alignment.Start)
        )

        LazyRow(modifier = Modifier.fillMaxSize()) {
            items(lista) { NoticiaBD ->
                cartaNoticia(
                    objetoDeLista = NoticiaBD,
                    navController = navController,
                    mapaNombreImagen2 = mapaNombreImagen2,
                    colorLetra = colorLetra,
                    colorFondo = colorFondo,
                    fuenteLetra = fuenteLetra,
                    colorMarco = colorMarco
                )
            }
        }
    }
}

@Composable
fun cartaNoticia(
    objetoDeLista: NoticiaBD,
    navController: NavController,
    mapaNombreImagen2: Map<String, String>,
    colorLetra: Color,
    colorFondo: Color,
    fuenteLetra: FontFamily,
    colorMarco: Color
) {

    Button(
        onClick = { navController.navigate(route = PantallaApp.Noticia.ruta + objetoDeLista.ID) },
        colors = ButtonDefaults.buttonColors(backgroundColor = Color.White),
        modifier = Modifier
            .fillMaxWidth()
            .size(width = 300.dp, height = 180.dp)
            .padding(start = 10.dp, top = 15.dp, end = 0.dp, bottom = 0.dp)
            .border(border = BorderStroke(2.dp, colorMarco), shape = CutCornerShape(3.dp))
    ){
        Box(modifier = Modifier.fillMaxWidth().fillMaxHeight()) {

            AsyncImage(
                model = mapaNombreImagen2.get(objetoDeLista.imagen),
                contentDescription = null,
                error = painterResource(id = R.drawable.imagenerror),
                placeholder = painterResource(id = R.drawable.imagenerror),
                contentScale = ContentScale.FillWidth,
                modifier = Modifier.fillMaxSize()
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(BottomCenter)
                    .padding(vertical = 5.dp) // no es tan necesario este padding
                    .background(colorFondo)
            ) {

                Text(
                    text = objetoDeLista.titulo,
                    textAlign = TextAlign.Center,
                    fontFamily = fuenteLetra,
                    color = colorLetra,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                )

            }

        }
    }
}