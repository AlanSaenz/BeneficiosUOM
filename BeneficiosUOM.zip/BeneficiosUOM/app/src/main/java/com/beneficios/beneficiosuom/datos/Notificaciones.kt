package com.beneficios.beneficiosuom.datos

// Notificacion   ------------------------------------------------------
data class NotificacionBD(
    var id: Int,
    var titulo: String,
    var descripcion: String
) {
    constructor() : this(0,"","")
}