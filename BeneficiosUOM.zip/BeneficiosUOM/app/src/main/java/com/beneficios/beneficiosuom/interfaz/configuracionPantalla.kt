package com.beneficios.beneficiosuom.interfaz

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.beneficios.beneficiosuom.R
import com.beneficios.beneficiosuom.datos.Configuracion
import com.beneficios.beneficiosuom.navegacion.PantallaApp
import androidx.compose.material.Text as text

// CONFIGURACION ------------------------------------------------------------------------------

@Composable
fun configuracion(
    navController: NavController,
    fuenteLetra: FontFamily,
    imgFondo: String
) {
    val fondoEngranaje = painterResource(id = R.drawable.fondonewfinal)

    var ListaDeConfiguracion = listOf<Configuracion>(
        Configuracion(
            "Enviar notificacion a todos",
            "Se enviara una notificacion a todos los usuarios, que se almacenara en la bandeja de notificaciones de cada usuario.",
            "notificaciontodos"
        ),
        Configuracion("------", "En proceso", "configuracion"),
        //Configuracion("","")
    )

    AsyncImage(
        model = imgFondo,
        contentDescription = null,
        error = fondoEngranaje,
        placeholder = painterResource(id = R.drawable.imagencarga),
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(),
        contentScale = ContentScale.FillWidth
    )

    LazyColumn {

        item {
            Toolbar3(
                titulo = "Configuracion",
                fondo = Color.White,
                letra = Color.Black,
                fuente = fuenteLetra,
                navController
            )
        }

        items(ListaDeConfiguracion) {
            configuracionCarta(config = it, fuenteLetra = fuenteLetra, navController)
        }
    }

}

// NOTIFICACIONES CARTA ------------------------------------------------------------------------------

@Composable
fun configuracionCarta(
    config: Configuracion,
    fuenteLetra: FontFamily,
    navController: NavController
) {


    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth(1f)
            .padding(10.dp)
            .border(border = BorderStroke(3.dp, Color.Black), shape = RoundedCornerShape(25.dp))
            .clickable { navController.navigate(route = config.direccionPantalla) }
    ) {

        text(
            text = config.titulo,
            textAlign = TextAlign.Center,
            fontSize = 25.sp,
            fontFamily = fuenteLetra,
            color = Color.Black,
            style = MaterialTheme.typography.h6,
            modifier = Modifier.padding(top = 5.dp)
        )

        text(
            text = config.descripcion,
            textAlign = TextAlign.Center,
            fontSize = 17.sp,
            fontFamily = fuenteLetra,
            color = Color.Black,
            fontWeight = FontWeight.Black,
            style = MaterialTheme.typography.h6,
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 10.dp)
        )

    }

    Spacer(modifier = Modifier.width(5.dp))

}