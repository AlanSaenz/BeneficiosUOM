package com.beneficios.beneficiosuom.interfaz

import android.annotation.SuppressLint
import android.content.ContentValues
import android.graphics.fonts.FontFamily
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.beneficios.beneficiosuom.R
import com.beneficios.beneficiosuom.datos.BeneficiarioBD
import com.beneficios.beneficiosuom.ui.theme.roboto
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage


val storage = Firebase.storage // CONEXION A STORAGE
var storageRef = storage.reference // Create a storage reference from our app


@SuppressLint("CoroutineCreationDuringComposition")
@Composable
fun Credencial(
    navController: NavController,
    usuario: BeneficiarioBD,
    colorLetra:Color,
    fuenteLetra:androidx.compose.ui.text.font.FontFamily,
    modifier: Modifier
) {

    Box(
        contentAlignment = Alignment.TopStart,
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight()
    ) {

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .background(color = Color.Black)
        ) {

            Spacer(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
            )

            Image(
                painter = painterResource(id = R.drawable.credencial_volteada),
                contentDescription = "Credencial",
                contentScale = ContentScale.FillWidth,
                modifier = Modifier
                    .fillMaxSize()

            )
        }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top,
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight()
    ) {

        Spacer(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
        )

        Text(
            text = "Nombre Completo: ${usuario.nombreCompleto} \nDNI: ${usuario.DNI} \nFabrica: ${usuario.fabrica} ",
            fontSize = 25.sp,
            fontFamily = fuenteLetra,
            color = colorLetra,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Start,
            lineHeight = 55.sp,
            overflow = TextOverflow.Visible,
            softWrap = false,
            modifier = Modifier
                .rotate(90F)

        )

    }

    ToolbarCredencial(
        titulo = "Credencial",
        fondo = Color.Black,
        letra = Color.White,
        fuente = fuenteLetra,
        navController = navController
    )

}