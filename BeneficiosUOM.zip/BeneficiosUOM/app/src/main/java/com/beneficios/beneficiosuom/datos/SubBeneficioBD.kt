package com.beneficios.beneficiosuom.datos

// SUB-BENEFICIO   ------------------------------------------------
data class SubBeneficioBD(
    var ID: Int,
    var IDOrigen: Int,
    var descripcion: String,
    var porcentaje: Int
) {
    constructor() : this(0,0,"",0)
}
