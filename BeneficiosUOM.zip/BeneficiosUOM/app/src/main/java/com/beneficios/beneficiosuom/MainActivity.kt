package com.beneficios.beneficiosuom

//import android.app.NotificationChannel
//import android.app.NotificationManager
//import android.content.Context
//import androidx.core.app.NotificationCompat


import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.beneficios.beneficiosuom.navegacion.NavegacionApp
import com.beneficios.beneficiosuom.ui.theme.BeneficiosUOMTheme

class MainActivity : ComponentActivity() {
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

/*
        //NOTIFICACIONES
        val Chanel_name = "Notificicaciones"
        val Chanel_ID = "IDnoti"
        val descriptionText = "Este es el canal de notificaciones y avisos"
        val importancia = NotificationManager.IMPORTANCE_DEFAULT

        // Canal de notificacion
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val Chanel_name = "Notificaciones"
            val Chanel_ID = "IDnoti"
            val descriptionText = "Este es el canal de notificaciones y avisos"
            val importancia = NotificationManager.IMPORTANCE_DEFAULT

            val channel = NotificationChannel(Chanel_ID, Chanel_name, importancia).apply {
                description = descriptionText
            }

            // Register the channel with the system )
            val notificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }

        // Notificaciones
        var titulo = "Titulo de la noti"
        var contenido = "Contenido de la noti"

        var builder = NotificationCompat.Builder(this, Chanel_ID)
            .setSmallIcon(R.drawable.icono)
            .setContentTitle(titulo)
            .setContentText(contenido)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
 */

        setContent {
            BeneficiosUOMTheme {

                Surface(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth()
                        .fillMaxSize(),
                    color = Color.White
                ) {
                    NavegacionApp()
                }

            }

        }
    }
}
