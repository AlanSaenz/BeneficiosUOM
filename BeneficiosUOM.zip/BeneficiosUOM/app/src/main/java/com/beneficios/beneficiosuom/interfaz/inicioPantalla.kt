package com.beneficios.beneficiosuom.interfaz

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.beneficios.beneficiosuom.R
import com.beneficios.beneficiosuom.datos.AdminBD
import com.beneficios.beneficiosuom.datos.BeneficiarioBD
import com.beneficios.beneficiosuom.navegacion.PantallaApp
import com.beneficios.beneficiosuom.ui.theme.roboto

@Composable
fun Inicio(
    navController: NavController,
    nombreCompleto: String,
    imgFondo: String,
    imgBandera: String,
    colorLetra: Color, colorMarco: Color, fuenteLetra: androidx.compose.ui.text.font.FontFamily,
    listaUsuarios: List<BeneficiarioBD>,
    listaAdmin: List<AdminBD>,
    modifier: Modifier = Modifier
        .fillMaxWidth()
        .fillMaxHeight()
) {

    //Iconos
    val bandera = painterResource(id = R.drawable.bandera40a_os_sinfondo)
    val iconoT = painterResource(id = R.drawable.iconoturismo)
    val iconoC = painterResource(id = R.drawable.comercionew)
    val iconoP = painterResource(id = R.drawable.iconoprensa2)
    val fondoEngranaje = painterResource(id = R.drawable.fondonewfinal)

    // Iconos redes sociales
    val socialF = painterResource(id = R.drawable.facebook)
    val socialY = painterResource(id = R.drawable.youtube)
    val socialI = painterResource(id = R.drawable.instagram)
    //val socialw = painterResource(id = R.drawable.whatsapp)

    // Enlace a cada link y context ----------- // VER PARA QUE ABRA LA APP DE FACEBOOK / INSTAGRAM / YOUTUBE
    val Link1 = "https://www.facebook.com/profile.php?id=100083098282103"
    val Link2 = "https://www.instagram.com/seccionalrg/"
    val Link3 = "https://www.facebook.com/profile.php?id=100083472215819"
    val Link4 = "https://www.youtube.com/@UOMseccionalRioGrande"

    val context = LocalContext.current

    val linkFP = remember { Intent(Intent.ACTION_VIEW, Uri.parse(Link1)) }
    val linkI = remember { Intent(Intent.ACTION_VIEW, Uri.parse(Link2)) }
    val linkFC = remember { Intent(Intent.ACTION_VIEW, Uri.parse(Link3)) }
    val linkY = remember { Intent(Intent.ACTION_VIEW, Uri.parse(Link4)) }

    // USUARIO

    var user = BeneficiarioBD()

    listaUsuarios.forEach {
        if (it.nombreCompleto == nombreCompleto) {
            user = it
        }
    }

    // -----------------------------------------------

    //imgFondo

    AsyncImage(
        model = imgFondo,
        contentDescription = null,
        error = fondoEngranaje,
        //placeholder = painterResource(id = R.drawable.imagencarga),
        placeholder = fondoEngranaje,
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(),
        contentScale = ContentScale.FillWidth
    )

    LazyColumn(
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Top
    ) {

        item { Spacer(modifier = Modifier.height(50.dp)) }

        item {
            AsyncImage(
                model = imgBandera,
                contentDescription = null,
                error = bandera,
                //placeholder = painterResource(id = R.drawable.imagencarga),
                placeholder = bandera,
                modifier = Modifier
                    .fillMaxWidth(),
                contentScale = ContentScale.FillWidth
            )

        }

        item {
            Text(
                text = ("¡Bienvenido $nombreCompleto!"),
                fontFamily = fuenteLetra,
                color = colorLetra,
                fontSize = 23.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp, horizontal = 0.dp)
            )
        }

        // Turismo -----------------------------------------------------------------------
        item {
            Spacer(modifier = Modifier.height(4.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top,
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
            ) {
                Row(horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { navController.navigate(route = PantallaApp.Turismo.ruta) }
                        .fillMaxWidth()
                        .padding(vertical = 20.dp, horizontal = 40.dp)
                        .border(
                            border = BorderStroke(2.dp, colorMarco), shape = CutCornerShape(3.dp)
                        )) {
                    Image(
                        painter = iconoT,
                        contentDescription = null,
                        modifier = Modifier
                            .size(100.dp)
                            .padding(8.dp)
                            .wrapContentWidth(Alignment.CenterHorizontally)
                            .wrapContentHeight(Alignment.CenterVertically),
                        contentScale = ContentScale.Crop
                    )
                    Text(
                        text = "Turismo",
                        fontSize = 30.sp,
                        fontFamily = fuenteLetra,
                        color = colorLetra,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .padding(vertical = 8.dp)
                            .wrapContentWidth(Alignment.CenterHorizontally)
                            .wrapContentHeight(Alignment.CenterVertically)
                            .padding(end = 20.dp)
                    )
                }
            }
        }

        // Comercio -----------------------------------------------------------------------
        item {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top,
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
            ) {
                Row(horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { navController.navigate(route = PantallaApp.Comercio.ruta) }
                        .fillMaxWidth()
                        .padding(vertical = 20.dp, horizontal = 40.dp)
                        .border(
                            border = BorderStroke(2.dp, colorMarco), shape = CutCornerShape(3.dp)
                        )) {
                    Image(
                        painter = iconoC,
                        contentDescription = null,
                        modifier = Modifier
                            .size(100.dp)
                            .padding(8.dp)
                            .wrapContentWidth(Alignment.CenterHorizontally)
                            .wrapContentHeight(Alignment.CenterVertically),
                        contentScale = ContentScale.Crop
                    )

                    Text(
                        text = "Comercio",
                        fontSize = 30.sp,
                        fontFamily = fuenteLetra,
                        color = colorLetra,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .padding(vertical = 8.dp)
                            .wrapContentWidth(Alignment.CenterHorizontally)
                            .wrapContentHeight(Alignment.CenterVertically)
                            .padding(end = 20.dp)
                    )

                }
            }
        }

        // Prensa -----------------------------------------------------------------------
        item {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top,
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
            ) {
                // PRENSA
                Row(horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { navController.navigate(route = PantallaApp.Prensa.ruta) }
                        .fillMaxWidth()
                        .padding(vertical = 20.dp, horizontal = 40.dp)
                        .border(
                            border = BorderStroke(2.dp, colorMarco), shape = CutCornerShape(3.dp)
                        )) {
                    Image(
                        painter = iconoP,
                        contentDescription = null,
                        modifier = Modifier
                            .size(105.dp)
                            .padding(start = 20.dp, top = 8.dp, end = 8.dp, bottom = 8.dp)
                            .wrapContentWidth(Alignment.CenterHorizontally)
                            .wrapContentHeight(Alignment.CenterVertically),
                        contentScale = ContentScale.Crop
                    )
                    Text(
                        text = "Prensa y difusión",
                        fontSize = 30.sp,
                        fontFamily = fuenteLetra,
                        color = colorLetra,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .padding(vertical = 8.dp)
                            .wrapContentWidth(Alignment.CenterHorizontally)
                            .wrapContentHeight(Alignment.CenterVertically)
                            .padding(end = 20.dp)
                    )

                }

            }
        }

        // Pie del INICIO -----------------------------------------------------------------------

        item {

            Spacer(modifier = Modifier.height(2.dp))

            Row(
                horizontalArrangement = Arrangement.Start,
                verticalAlignment = Alignment.Bottom,
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
            ) {

                var BanderaAdmin = 0
                listaAdmin.forEach {
                    if (user.DNI == it.DNI) {
                        BanderaAdmin = 1
                    }
                }

                if (BanderaAdmin == 0) {

                    Column(
                        horizontalAlignment = Alignment.Start,
                        verticalArrangement = Arrangement.Top,
                        modifier = Modifier
                    ) {
                        // TELEFONO UTILES

                        Row(
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(Color.Black)
                                .padding(horizontal = 10.dp, vertical = 7.dp)
                                .clickable { navController.navigate(route = PantallaApp.NumerosUtiles.ruta) } // Ruta a Numeros utiles
                        ) {
                            Spacer(modifier = Modifier.width(8.dp))

                            Image(
                                painter = painterResource(id = R.drawable.telefono_blanco),
                                contentDescription = null,
                                modifier = Modifier
                                    .size(25.dp),
                                contentScale = ContentScale.FillWidth
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            Text(
                                text = "Numeros utiles",
                                fontSize = 20.sp,
                                fontFamily = roboto,
                                color = Color.White,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                            )

                        }

                        Spacer(modifier = Modifier.height(30.dp))

                        // CREDENCIAL

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(Color.Black)
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                                .clickable { navController.navigate(route = PantallaApp.Credencial.ruta) }// Ruta a Credencial
                        ) {
                            Spacer(modifier = Modifier.width(8.dp))

                            Image(
                                painter = painterResource(id = R.drawable.tarjeta_blanco),
                                contentDescription = null,
                                modifier = Modifier
                                    .size(30.dp),
                                contentScale = ContentScale.FillWidth
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            Text(
                                text = "Credencial",
                                fontSize = 20.sp,
                                fontFamily = roboto,
                                color = Color.White,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                            )
                        }
                    }
                } else if (BanderaAdmin == 1) {
                    Column(
                        horizontalAlignment = Alignment.Start,
                        verticalArrangement = Arrangement.Top,
                        modifier = Modifier
                    ) {
                        // TELEFONO UTILES

                        Row(
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(Color.Black)
                                .padding(horizontal = 10.dp, vertical = 7.dp)
                                .clickable { navController.navigate(route = PantallaApp.NumerosUtiles.ruta) } // Ruta a Numeros utiles
                        ) {
                            Spacer(modifier = Modifier.width(8.dp))

                            Image(
                                painter = painterResource(id = R.drawable.telefono_blanco),
                                contentDescription = null,
                                modifier = Modifier
                                    .size(25.dp),
                                contentScale = ContentScale.FillWidth
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            Text(
                                text = "Numeros utiles",
                                fontSize = 20.sp,
                                fontFamily = roboto,
                                color = Color.White,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                            )

                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // CREDENCIAL

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(Color.Black)
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                                .clickable { navController.navigate(route = PantallaApp.Credencial.ruta) }// Ruta a Credencial
                        ) {
                            Spacer(modifier = Modifier.width(8.dp))

                            Image(
                                painter = painterResource(id = R.drawable.tarjeta_blanco),
                                contentDescription = null,
                                modifier = Modifier
                                    .size(30.dp),
                                contentScale = ContentScale.FillWidth
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            Text(
                                text = "Credencial",
                                fontSize = 20.sp,
                                fontFamily = roboto,
                                color = Color.White,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                            )
                        }


                        Spacer(modifier = Modifier.height(8.dp))

                        // ADMIN CONFIG

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(Color.Black)
                                .padding(horizontal = 1.dp, vertical = 5.dp)
                                .clickable { navController.navigate(route = PantallaApp.ContraAdmin.ruta) }
                        ) {
                            Spacer(modifier = Modifier.width(18.dp))

                            Image(
                                painter = painterResource(id = R.drawable.adminicono),
                                contentDescription = null,
                                modifier = Modifier
                                    .size(25.dp),
                                contentScale = ContentScale.FillWidth
                            )

                            Spacer(modifier = Modifier.width(10.dp))

                            Text(
                                text = "Admin",
                                fontSize = 18.sp,
                                fontFamily = roboto,
                                color = Color.White,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(end = 5.dp)
                            )
                        }
                    }
                }

                // REDES SOCIALES
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Top,
                        modifier = Modifier
                    ) {

                        Image(
                            painter = socialF,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(30.dp)
                                .clickable { context.startActivity(linkFP) }
                        )
                        Text(
                            text = "Prensa",
                            fontSize = 15.sp,
                            fontFamily = fuenteLetra,
                            color = Color.Black,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Top,
                        modifier = Modifier
                    ) {

                        Image(
                            painter = socialI,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(30.dp)
                                .clickable { context.startActivity(linkI) }
                        )
                        Text(text = "")
                    }

                    Spacer(modifier = Modifier.width(5.dp))

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Top,
                        modifier = Modifier
                    ) {
                        Image(
                            painter = socialF,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(30.dp)
                                .clickable { context.startActivity(linkFC) }
                        )
                        Text(
                            text = "Comercio",
                            fontSize = 15.sp,
                            fontFamily = fuenteLetra,
                            color = Color.Black,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                        )
                    }

                    Spacer(modifier = Modifier.width(5.dp))

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Top,
                        modifier = Modifier
                    ) {

                        Image(
                            painter = socialY,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(30.dp)
                                .clickable { context.startActivity(linkY) }
                                //.clickable { notificacionTodos(user, "Titulo prueba", "Descripcion prueba") }
                        )
                        Text(text = "")
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                }

            }

        }

        item {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.Top,
                modifier = Modifier.fillMaxWidth()
            ) {

                Spacer(modifier = Modifier.width(5.dp))

                Text(
                    text = "Desarrollado por Alan Saenz\nsoulwalkerdev@gmail.com",
                    fontFamily = fuenteLetra,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(end = 4.dp)
                )


            }
        }

    } // FIN LAZYCOLUM

    ToolbarInicio(
        titulo = "UOM Seccional Rio Grande",
        fuente = fuenteLetra,
        usuario = user,
        navController = navController
    )

}