package com.beneficios.beneficiosuom.interfaz

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.Text
import androidx.compose.material.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.beneficios.beneficiosuom.datos.BeneficiarioBD
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.navigation.NavController
import com.beneficios.beneficiosuom.navegacion.PantallaApp
import com.google.firebase.annotations.concurrent.Background

@Composable
fun PantallaEmergente() {

    var showDialog by remember { mutableStateOf(false) }

    Column {
        Button(onClick = { showDialog = true }) {

            Text("Mostrar ventana emergente")
        }

        if (showDialog) {

            AlertDialog(
                onDismissRequest = { showDialog = false },
                title = { Text("Título de la ventana emergente") },
                text = { Text("Contenido de la ventana emergente") },
                confirmButton = {
                    Button(
                        onClick = { showDialog = false },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(0.dp, 0.dp, 12.dp, 12.dp)
                    ) {
                        Text("Aceptar")
                    }
                },
                modifier = Modifier.padding(16.dp)
            )
        }
    }
}


fun HacerEnvioNoti(listaUsuarios: List<BeneficiarioBD>, titulo: String, descrip: String) {
    listaUsuarios.forEach {
        notificacionTodos(it, titulo = titulo, descripcion = descrip)
    }
}


@Composable
fun notificarTodos(
    fuenteLetra: FontFamily,
    listaUsuarios: List<BeneficiarioBD>,
    navController: NavController
) {

    var showDialog by remember { mutableStateOf(false) }
    var showDialog2 by remember { mutableStateOf(false) }

    var tituloNoti by remember { mutableStateOf("") }
    var descripcionNoti by remember { mutableStateOf("") }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .padding(15.dp)
            .fillMaxWidth(1f)
            .fillMaxHeight(1f)
            .background(Color.White)
            .border(
                border = BorderStroke(3.dp, Color.Black)
            )
    ) {

        Text(
            text = "Ingrese el titulo de la Notificacion",
            fontSize = 22.sp,
            fontFamily = fuenteLetra,
            color = Color.Black,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(15.dp))

        TextField(
            value = tituloNoti,
            onValueChange = { tituloNoti = it },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            label = { Text("Titulo") },
            modifier = Modifier
                .background(Color.White)
                .border(
                    border = BorderStroke(3.dp, Color.Black)
                )
        )

        Spacer(modifier = Modifier.height(40.dp))


        Text(
            text = "Ingrese la descripcion de la Notificacion",
            fontSize = 20.sp,
            fontFamily = fuenteLetra,
            color = Color.Black,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(15.dp))

        TextField(
            value = descripcionNoti,
            onValueChange = { descripcionNoti = it },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            label = { Text("Descripcion") },
            modifier = Modifier
                .background(Color.White)
                .border(
                    border = BorderStroke(3.dp, Color.Black)
                )
        )

        Spacer(modifier = Modifier.height(55.dp))

        Text(
            text = "Enviar notificacion ",
            color = Color.Black,
            fontSize = 20.sp,
            fontFamily = fuenteLetra,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth(0.6f)
                .height(80.dp)
                .border(border = BorderStroke(3.dp, Color.Black))
                .padding(29.dp)
                .clickable {
                    if (tituloNoti != "" || descripcionNoti != "") {
                        HacerEnvioNoti(
                            listaUsuarios = listaUsuarios,
                            titulo = tituloNoti.toString(),
                            descrip = descripcionNoti.toString()
                        )
                        showDialog2 = true
                    } else {
                        showDialog = true
                    }
                }
        )

        if (showDialog) {
            AlertDialog(
                onDismissRequest = { showDialog = false },
                title = { Text("Error al enviar Notificacion") },
                text = { Text("Se ingreso el Titulo o la Descripcion vacia. Intentelo de nuevo.") },
                confirmButton = {
                    Button(
                        onClick = { showDialog = false },
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color.White),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(0.dp, 0.dp, 12.dp, 12.dp)
                    ) {
                        Text(
                            "Aceptar",
                            color = Color.Black
                        )
                    }
                },
                modifier = Modifier.padding(16.dp)
            )
        }

        if (showDialog2) {
            AlertDialog(
                onDismissRequest = {
                    showDialog = false
                    navController.popBackStack()
                    navController.navigate(route = PantallaApp.Configuracion.ruta)
                },
                title = { Text("Se envio correctamente la notificacion Notificacion") },
                text = { Text("Se esta procesando el envio de la notificacion a todos los usuarios, esto puede tardar entre 20 segundos a 1 min. Ya puede salir de esta ventana y volver al inicio.") },
                confirmButton = {
                    Button(
                        onClick = {
                            showDialog = false
                            navController.popBackStack()
                            navController.navigate(route = PantallaApp.Configuracion.ruta)
                        },
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color.White),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(0.dp, 0.dp, 12.dp, 12.dp)
                    ) {
                        Text(
                            "Aceptar",
                            color = Color.Black
                        )
                    }
                },
                modifier = Modifier.padding(16.dp)
            )
        }

    }

    Toolbar2(
        titulo = "Notificacion",
        fondo = Color.White,
        letra = Color.Black,
        fuente = fuenteLetra,
        navController = navController
    )

}