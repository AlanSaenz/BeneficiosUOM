package com.beneficios.beneficiosuom.navegacion

import android.content.ContentValues
import android.util.Log
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.beneficios.beneficiosuom.datos.*
import com.beneficios.beneficiosuom.interfaz.*
import com.beneficios.beneficiosuom.ui.theme.roboto
import com.beneficios.beneficiosuom.ui.theme.saberColor
import com.beneficios.beneficiosuom.ui.theme.saberColor2
import com.beneficios.beneficiosuom.ui.theme.saberFuente
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.toObjects
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage
import com.google.firebase.storage.ktx.component1

@Composable
fun NavegacionApp() {

    //DATOS
    val navController = rememberNavController() // Controlador de intercambio de pantallas
    val db = FirebaseFirestore.getInstance() // CONEXION A LA BASE DE DATOS

    //IMAGENES
    val storage = Firebase.storage // CONEXION A STORAGE
    val storageRef = storage.reference // Create a storage reference from our app

    //-------------------------------------------------------------------------- Pruebas LISTA DE IMAGENES

    val listaRef = storageRef.child("Beneficios")

    var listaComercioIMGRef = mutableListOf<StorageReference>()
    var mapaNombreImagen = mutableMapOf<String, String>()

    listaRef.listAll()
        .addOnSuccessListener { (items) ->

            items.forEach { item ->
                listaComercioIMGRef = items as MutableList<StorageReference>
            }

            listaComercioIMGRef.forEach { resultado ->

                storage.getReferenceFromUrl(resultado.toString()).downloadUrl.addOnSuccessListener {
                    mapaNombreImagen.set(resultado.name, it.toString())

                }.addOnFailureListener {
                    Log.d(
                        ContentValues.TAG,
                        "Proceso Lista de Imagenes 2 de 2. ERROR, SE CHINGO TODO WE"
                    )
                }

            }
        }.addOnFailureListener {
            Log.d(
                ContentValues.TAG,
                "Proceso Lista de Imagenes 1 de 2. ERROR, SE CHINGO TODO WE"
            )
        }

    //-----------------------------------------------

    val listaRef2 = storageRef.child("Noticias")

    var listaComercioIMGRef2 = mutableListOf<StorageReference>()
    var mapaNombreImagen2 = mutableMapOf<String, String>()

    listaRef2.listAll()
        .addOnSuccessListener { (items) ->

            items.forEach { item ->
                listaComercioIMGRef2 = items as MutableList<StorageReference>
                Log.d(ContentValues.TAG, "Proceso Lista de Imagenes NOTICIAS. FINALIZADO")
                //Log.d(ContentValues.TAG, "$listaComercioIMGRef2")
            }

            listaComercioIMGRef2.forEach { resultado ->

                storage.getReferenceFromUrl(resultado.toString()).downloadUrl.addOnSuccessListener {
                    mapaNombreImagen2.set(resultado.name, it.toString())

                    Log.d(ContentValues.TAG, "Proceso Lista de Imagenes NOTICIAS. FINALIZADO")
                    //Log.d(ContentValues.TAG, "$mapaNombreImagen2")

                }.addOnFailureListener {
                    Log.d(
                        ContentValues.TAG,
                        "Proceso Lista de Imagenes NOTICIAS 2 de 2. ERROR, SE CHINGO TODO WE"
                    )
                }
            }
        }
        .addOnFailureListener {
            Log.d(ContentValues.TAG, "Proceso Lista de Imagenes 1 de 2. ERROR, SE CHINGO TODO WE")
        }

    //------------------------------------------------------------- Carga de imagen EJEMPLO

    /*
    var imagen1NEW = ""

    val Name = "imagenCredencial/Credencial1.png"
    val credencialRef = storageRef.child(Name)

    credencialRef.downloadUrl.addOnSuccessListener {
        imagen1NEW = it.toString()
    }.addOnFailureListener {
        // Handle any errors
    }
     */

    //--------------------------------------------------------------------------
    // Nuevas lista de cada cosa tomada de la base de Datos FIREBASE

    var newListBeneficio = mutableListOf<BeneficioBD>()
    var newListSubBeneficio = mutableListOf<SubBeneficioBD>()
    var newListNoticia = mutableListOf<NoticiaBD>()
    var newListTelefonos = mutableListOf<NumerosUtilesBD>()
    var newListUsuarios = mutableListOf<BeneficiarioBD>()
    var newListAdmin = mutableListOf<AdminBD>()

    // CARGA DE BASE DE DATOS - Beneficio ♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦
    var baseListaBeneficio = db.collection("Beneficio")
        .get().addOnSuccessListener() {
            newListBeneficio = it.toObjects<BeneficioBD>().toMutableList()

            Log.d(ContentValues.TAG, "Carga de lista Beneficio FINALIZADA 1")
            //Log.d(ContentValues.TAG, "$newListBeneficio")
        }.addOnFailureListener { Log.d(ContentValues.TAG, "ERROR CARGA BENEFICIO") }

    // CARGA DE BASE DE DATOS - SubBeneficio ♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦
    var baseListaSubBeneficio = db.collection("SubBeneficio")
        .get().addOnSuccessListener() {
            newListSubBeneficio = it.toObjects<SubBeneficioBD>().toMutableList()

            Log.d(ContentValues.TAG, "Carga de lista SubBeneficio FINALIZADA 1.2")
            //Log.d(ContentValues.TAG, "$newListBeneficio")
        }.addOnFailureListener { Log.d(ContentValues.TAG, "ERROR CARGA SUBENEFICIO") }

    // CARGA DE BASE DE DATOS - Noticia ♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦
    var baseListaNoticia = db.collection("Noticia")
        .get().addOnSuccessListener() {
            newListNoticia = it.toObjects<NoticiaBD>().toMutableList()

            Log.d(ContentValues.TAG, "Carga de lista Noticia FINALIZADA 2")
            //Log.d(ContentValues.TAG, "$newListNoticia")
        }.addOnFailureListener { Log.d(ContentValues.TAG, "ERROR CARGA NOTICIA") }

    // CARGA DE BASE DE DATOS - Telefonos Utiles ♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦
    var baseListaTelefonos = db.collection("TelefonosUtiles")
        .get().addOnSuccessListener() {
            newListTelefonos = it.toObjects<NumerosUtilesBD>().toMutableList()

            Log.d(ContentValues.TAG, "Carga de lista Telefonos FINALIZADA 3")
            //Log.d(ContentValues.TAG, "$newListTelefonos")
        }.addOnFailureListener { Log.d(ContentValues.TAG, "ERROR CARGA NUMERO UTILES") }

    // CARGA DE BASE DE DATOS - USUARIOS ♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦
    var baseListaUsuarios = db.collection("Usuario")
        .get().addOnSuccessListener() {
            newListUsuarios = it.toObjects<BeneficiarioBD>().toMutableList()

            Log.d(ContentValues.TAG, "Carga de lista Usuario FINALIZADA 4")
            //Log.d(ContentValues.TAG, "$newListUsuarios")
        }.addOnFailureListener { Log.d(ContentValues.TAG, "ERROR CARGA USUARIO") }

    // CARGA DE BASE DE DATOS - ADMIN ♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦♦
    var baseListaAdmin = db.collection("Administrador")
        .get().addOnSuccessListener() {
            newListAdmin = it.toObjects<AdminBD>().toMutableList()

            Log.d(ContentValues.TAG, "Carga de lista ADMIN FINALIZADA 5")
            //Log.d(ContentValues.TAG, "$newListAdmin")
        }.addOnFailureListener { Log.d(ContentValues.TAG, "ERROR CARGA USUARIO") }

    //--------------------------------------------------------------------------
    // CONFIGURACION DE FUENTE Y COLOR ETC...

    data class Config1(var configuracion: String) {
        constructor() : this("")
    }

    var newConfiguracion = mutableListOf<Config1>()

    var ListaConfiguracion = db.collection("Configuracion").get().addOnSuccessListener() {
        newConfiguracion = it.toObjects<Config1>().toMutableList()

        Log.d(ContentValues.TAG, "Carga de CONFIGURACION FINALIZADA ♥")
        //Log.d(ContentValues.TAG, "$newConfiguracion")

    }.addOnFailureListener { Log.d(ContentValues.TAG, "ERROR CARGA CONFIGURACION") }

    //--------------------------------------------------------------------------
    // CONTRASEÑA DE ADMINISTRADORES DE BD

    data class ContraClass(var Contraseña: String) {
        constructor() : this("")
    }

    var ListaContra = mutableListOf<ContraClass>()

    var contraseñaBD = ""

    var ContraBASEDEDATOS = db.collection("ContraseñaAdmin").get().addOnSuccessListener() {

        ListaContra = it.toObjects<ContraClass>().toMutableList()

        contraseñaBD = ListaContra[0].Contraseña.toString()

        Log.d(ContentValues.TAG, "Carga de CONTRASEÑA OK")

    }.addOnFailureListener { Log.d(ContentValues.TAG, "ERROR CARGA CONTRASEÑA ADMIN") }


    //------------------------------------------------------------------------------------------------------------------
    // Imagen de fondo

    //val fondoEngranaje = painterResource(id = R.drawable.fondonewfinal)

    var fondoBD = ""
    val Nameimg = "ImagenesIconos/FondoInicio.png"
    val fondoRefIMG = storageRef.child(Nameimg)

    fondoRefIMG.downloadUrl.addOnSuccessListener {
        fondoBD = it.toString()
    }.addOnFailureListener {
        Log.d(ContentValues.TAG, "ERROR, SE CHINGO TODO WE CON LA IMAGEN")
    }

    //-----------------------------------------------------------------------------------------
    // Imagen de la base de datos 1 (bandera)

    var img1BD = ""
    val Nameimg1 = "ImagenesIconos/Bandera40Años.png"
    val img1RefIMG = storageRef.child(Nameimg1)

    img1RefIMG.downloadUrl.addOnSuccessListener {
        img1BD = it.toString()
    }.addOnFailureListener {
        Log.d(ContentValues.TAG, "ERROR CARGA DE IMAGEN DE FOND")
    }

    //--------------------------------------------------------------------------
    // Usuario que ingresa

    var usuario: BeneficiarioBD = BeneficiarioBD()

    //---------------------------------------------------------------------------------------------------------------- ♥♥♥
    //RUTAS

    NavHost(navController = navController, startDestination = PantallaApp.Splash.ruta) {

        // La ruta a la pantalla SPLASH
        composable(route = PantallaApp.Splash.ruta) {
            splashPantalla(navController)
        }

        // La ruta a la pantalla DNI
        composable(route = PantallaApp.DNI.ruta) {
            pruebaCargaDNI(
                navController,
                newListUsuarios = newListUsuarios,
                //fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase())      -- Pasa que no llega a cargar la fuente de letra y Crashea la APP (REVISAR)
                fuenteLetra = roboto
            )
        }

        // La ruta a la pantalla ERROR DNI
        composable(route = PantallaApp.ErrorDNI.ruta) {
            ErrorDNI(
                navController = navController,
                fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase())
            )
        }

        // La ruta a la pantalla INICIO
        composable(
            route = PantallaApp.Inicio.ruta + "{text}",
            arguments = listOf(navArgument(name = "text") {
                type = NavType.StringType
            })
        ) {
            if (usuario.nombreCompleto == "") {

                for (usuariolista in newListUsuarios) {
                    if (usuariolista.DNI.toString() == it.arguments?.getString("text").toString()) {
                        usuario = usuariolista
                    }
                }

                Inicio(
                    navController = navController,
                    nombreCompleto = usuario.DNI.toString(),
                    imgFondo = fondoBD,
                    imgBandera = img1BD,
                    colorLetra = saberColor(newConfiguracion[1].configuracion.lowercase()),
                    colorMarco = saberColor(newConfiguracion[2].configuracion.lowercase()),
                    fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase()),
                    newListUsuarios,
                    newListAdmin
                )

            } else {

                for (usuariolista in newListUsuarios) {
                    if (usuariolista.DNI.toString() == usuario.DNI.toString()) {
                        usuario = usuariolista
                    }
                }

                Inicio(
                    navController,
                    nombreCompleto = usuario.nombreCompleto.toString(),
                    imgFondo = fondoBD,
                    imgBandera = img1BD,
                    colorLetra = saberColor(newConfiguracion[1].configuracion.lowercase()),
                    colorMarco = saberColor(newConfiguracion[2].configuracion.lowercase()),
                    fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase()),
                    newListUsuarios,
                    newListAdmin
                )
            }

        }

        // La ruta a la pantalla INICIO-Volver
        composable(route = PantallaApp.Inicio.ruta) {

            if (usuario.nombreCompleto == "") {
                pruebaCargaDNI(
                    navController,
                    newListUsuarios = newListUsuarios,
                    fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase())
                )
            } else {
                Inicio(
                    navController,
                    nombreCompleto = usuario.nombreCompleto.toString(),
                    imgFondo = fondoBD,
                    imgBandera = img1BD,
                    colorLetra = saberColor(newConfiguracion[1].configuracion.lowercase()),
                    colorMarco = saberColor(newConfiguracion[2].configuracion.lowercase()),
                    fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase()),
                    newListUsuarios,
                    newListAdmin
                )
            }

        }


        // La ruta a la pantalla COMERCIO
        composable(route = PantallaApp.Comercio.ruta) {
            Comercio(
                navController,
                colorLetra = saberColor(newConfiguracion[5].configuracion.lowercase()),
                colorMarco = saberColor(newConfiguracion[6].configuracion.lowercase()),
                fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase()),
                imgFondo = fondoBD,
            )
        }

        // La ruta a la pantalla TURISMO
        composable(route = PantallaApp.Turismo.ruta) {
            Turismo(
                navController,
                colorLetra = saberColor(newConfiguracion[3].configuracion.lowercase()),
                colorMarco = saberColor(newConfiguracion[4].configuracion.lowercase()),
                fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase()),
                imgFondo = fondoBD,
            )
        }

        // La ruta a la pantalla PRENSA
        composable(route = PantallaApp.Prensa.ruta) {
            Prensa(
                navController,
                newListNoticia,
                mapaNombreImagen2 = mapaNombreImagen2,
                imgFondo = fondoBD,
                colorLetra = saberColor2(newConfiguracion[10].configuracion.lowercase()),
                colorMarco = saberColor(newConfiguracion[11].configuracion.lowercase()),
                fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase()),
                colorFondo = saberColor(newConfiguracion[9].configuracion.lowercase())
            )
        }

        // La ruta a la pantalla LISTA
        composable(
            route = PantallaApp.Lista.ruta + "/{text}",
            arguments = listOf(navArgument(name = "text") {
                type = NavType.StringType
            })
        ) {
            ListaDefinitiva(
                text = it.arguments?.getString("text"),
                lista = newListBeneficio,
                navController = navController,
                mapaNombreImagen = mapaNombreImagen,
                fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase())
            )
        }

        // La ruta a la pantalla DETALLE
        composable(
            route = PantallaApp.Detalle.ruta + "{numero}",
            arguments = listOf(navArgument(name = "numero") {
                type = NavType.IntType
            })
        ) {
            Detalle(
                navController = navController,
                listaCompleta = newListBeneficio,
                numero = it.arguments?.getInt("numero"),
                listaSub = newListSubBeneficio,
                mapaNombreImagen = mapaNombreImagen,
                colorLetra = saberColor2(newConfiguracion[8].configuracion.lowercase()),
                fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase()),
                colorFondo = saberColor(newConfiguracion[7].configuracion.lowercase())
            )
        }

        // La ruta a la pantalla NOTICIA
        composable(
            route = PantallaApp.Noticia.ruta + "{numero}",
            arguments = listOf(navArgument(name = "numero") {
                type = NavType.IntType
            })
        ) {
            DetalleNoticia(
                numero = it.arguments?.getInt("numero"),
                listaCompleta = newListNoticia,
                navController,
                mapaNombreImagen2 = mapaNombreImagen2,
                fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase()),
                colorFondo = saberColor2(newConfiguracion[12].configuracion.lowercase()),
                colorLetra = saberColor(newConfiguracion[13].configuracion.lowercase()),
                colorMarco = saberColor(newConfiguracion[14].configuracion.lowercase()),
            )
        }

        // La ruta a la pantalla NUMEROS UTILES
        composable(route = PantallaApp.NumerosUtiles.ruta) {
            NumerosUtiles(
                newListTelefonos, navController,
                colorLetra = saberColor(newConfiguracion[15].configuracion.lowercase()),
                colorMarco = saberColor(newConfiguracion[16].configuracion.lowercase()),
                fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase())
            )
        }

        // La ruta a la pantalla CRENDENCIAL
        composable(route = PantallaApp.Credencial.ruta) {
            Credencial(
                navController = navController,
                usuario = usuario,
                modifier = Modifier,
                colorLetra = saberColor(newConfiguracion[17].configuracion.lowercase()),
                fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase())
            )
        }

        // La ruta a la pantalla NOTIFICACIONES
        composable(route = PantallaApp.Notificacion.ruta) {
            notificaciones(navController = navController, fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase()), listaUsuarios = newListUsuarios, usuario = usuario, imgFondo = fondoBD)
        }

        // La ruta a la pantalla CONFIGURACION
        composable(route = PantallaApp.Configuracion.ruta) {
            configuracion(navController = navController, fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase()),imgFondo = fondoBD)
        }

        // La ruta a la pantalla ENVIAR A TODOS NOTIFICACION
        composable(route = PantallaApp.NotificacionTodos.ruta) {
            notificarTodos(fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase()), listaUsuarios = newListUsuarios, navController = navController)
        }

        // La ruta a la pantalla CONTRASEÑA ADMIN
        composable(route = PantallaApp.ContraAdmin.ruta) {
            contraseñaAdminPantalla(navController = navController, contraBD = contraseñaBD, fuenteLetra = saberFuente(newConfiguracion[0].configuracion.lowercase()))
        }
    }
}