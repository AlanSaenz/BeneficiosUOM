package com.beneficios.beneficiosuom.datos

import android.annotation.SuppressLint
import android.content.ContentValues.TAG
import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.beneficios.beneficiosuom.navegacion.*

@SuppressLint("StaticFieldLeak")
val db = FirebaseFirestore.getInstance()

fun SubirDatosDB() {
    val beneficio0 = hashMapOf(
        "ID" to 0,
        "lugar" to "",
        "descripcionCompleta" to "",
        "descripcionCorta" to "",
        "ubicacion" to "",
        "telefono" to "",
        "horario" to "",
        "imagen" to "",
        "categoria" to "",
        "descuentoSINO" to true,
        "tarifaSINO" to false,
    )

/*
    val beneficio1 = hashMapOf("ID" to 1,"lugar" to "Grande Hotel","descripcionCompleta" to "Ubicado frente al Aeropuerto Internacional Gobernador Ramón Trejo Noel, este hotel informal se encuentra a 2 km de las exhibiciones históricas del Museo Virginia Choquintel y a 3 km del Museo Fueguino de Arte.\nSe ofrece desayuno tipo buffet. Las comodidades incluyen un cálido restaurante con salón privado y un bar. El spa cuenta con piscina cubierta climatizada, tina, gimnasio y sauna.","descripcionCorta" to "Todo lo que buscás en un sólo lugar. Disponemos de 64 habitaciones completamente equipadas, Restaurante, Bar, Spa y Piscina, Salón de Eventos.","ubicacion" to "Federico Echelaine 251","telefono" to "2964 - 436500","horario" to "24hs","imagen" to "ID1.png","categoria" to "Hoteleria","descuentoSINO" to true,"tarifaSINO" to true)
    val beneficio2 = hashMapOf("ID" to 2,"lugar" to "Mercado el Puente","descripcionCompleta" to "Mercado para compras de primera necesidad, Carniceria , Almacen, Articulos de limpieza, fiambreria, bebidas y mas.","descripcionCorta" to "El Mercado mas famoso con 3 sucursales.","ubicacion" to "BELGRANO 1962\nSHELKNAN 302\nAlambrador 997","telefono" to "02964 54-6871","horario" to "Lun a Vier 10:00 a 21:00hs\nDom 10:00 a 13:00hs","imagen" to "ID2.png","categoria" to "Varios","descuentoSINO" to true,"tarifaSINO" to false)

    db.collection("Beneficio").document(beneficio1.get("ID").toString()).set(beneficio1).addOnSuccessListener {Log.d(TAG, "Beneficio cargado con la ID: ${beneficio1.get("ID")}")}.addOnFailureListener { e ->Log.w(TAG, "Error adding document", e)}
    db.collection("Beneficio").document(beneficio2.get("ID").toString()).set(beneficio2).addOnSuccessListener {Log.d(TAG, "Beneficio cargado con la ID: ${beneficio2.get("ID")}")}.addOnFailureListener { e ->Log.w(TAG, "Error adding document", e)}
 */

}// Fin de la funcion

fun SubirDatosDB2() {
    val sub0 = hashMapOf(
        "ID" to 0,
        "IDOrigen" to 0,
        "descripcion" to "",
        "porcentaje" to 0
    )
/*
    val sub1 = hashMapOf("ID" to 1,"IDOrigen" to 1,"descripcion" to "Alojamiento.","porcentaje" to 10)
    val sub2 = hashMapOf("ID" to 2,"IDOrigen" to 1,"descripcion" to "Gastronomia.","porcentaje" to 5)

    db.collection("SubBeneficio").document(sub1.get("ID").toString()).set(sub1).addOnSuccessListener {Log.d(TAG, "SubBeneficio cargado con la ID: ${sub1.get("ID")}")}.addOnFailureListener { e ->Log.w(TAG, "Error adding document", e)}
    db.collection("SubBeneficio").document(sub2.get("ID").toString()).set(sub2).addOnSuccessListener {Log.d(TAG, "SubBeneficio cargado con la ID: ${sub2.get("ID")}")}.addOnFailureListener { e ->Log.w(TAG, "Error adding document", e)}

 */

}// Fin de la funcion

fun SubirDatosDB3() {

    val usuario0 = hashMapOf(
        "ID" to 0,
        "nombreCompleto" to "",
        "DNI" to 0,
        "fabrica" to "",
        "estado" to false
    )

    //val usuario2119 = hashMapOf("ID" to 2119,"nombreCompleto" to "RUIZ NICOLAS IGNACIO","DNI" to 34484063,"fabrica" to "BRIGHTSTAR", "estado" to false)
    //db.collection("Usuario").document(usuario2119.get("ID").toString()).set(usuario2119).addOnSuccessListener {Log.d(TAG, "Usuario cargado con laID: ${usuario2119.get("ID")}")}.addOnFailureListener { e ->Log.w(TAG, "Error adding document", e)}

}// Fin de la funcion

fun SubirDatosDB4() {

    val telefono0 = hashMapOf(
        "ID" to 0,
        "nombre" to "0",
        "telefono" to "0",
        "direccion" to "0",
    )

    val telefono1 = hashMapOf(
        "ID" to 1,
        "nombre" to "Gremio UOM Rio Grande",
        "telefono" to "02964 43-0616",
        "direccion" to "Carlos Moyano 431",
    )

    val telefono2 = hashMapOf(
        "ID" to 2,
        "nombre" to "Sanatorio Fueguino",
        "telefono" to "426371/427121/425086/427441",
        "direccion" to "Cordoba 748",
    )

    // Telefono 1
    db.collection("TelefonosUtiles").document(telefono1.get("ID").toString()).set(telefono1)
        .addOnSuccessListener {
            Log.d(TAG, "TelefonosUtiles cargado con la ID: ${telefono1.get("ID")}")
        }
        .addOnFailureListener { e ->
            Log.w(TAG, "Error adding document", e)
        }

    // Telefono 2
    db.collection("TelefonosUtiles").document(telefono2.get("ID").toString()).set(telefono2)
        .addOnSuccessListener {
            Log.d(TAG, "TelefonosUtiles cargado con la ID: ${telefono2.get("ID")}")
        }
        .addOnFailureListener { e ->
            Log.w(TAG, "Error adding document", e)
        }

}// Fin de la funcion<

fun SubirDatosDB5() {

    val noticia0 = hashMapOf(
        "ID" to 0,
        "titulo" to "",
        "contenido" to "",
        "fechaDeCreacion" to "",
        "categoria" to "",
        "imagen" to "",
    )

    val noticia1 = hashMapOf(
        "ID" to 1,
        "titulo" to "Problemas en ...",
        "contenido" to "Lorem ipsum dolor sit amet. Est rerum fuga id ipsum vitae aut quaerat rerum ut tempore rerum et vitae inventore quo provident facilis ut consequuntur ratione. Et architecto autem et eveniet odit aut fuga dolorum et pariatur quisquam est amet commodi et animi perferendis. Sit officia ipsum qui facere reprehenderit ab internos officia. Et aspernatur culpa et repudiandae quasi et pariatur sequi et dolorum odit ut labore veniam eum delectus recusandae?\n" +
                "\n" +
                "In praesentium omnis vel culpa placeat non praesentium voluptatem sit autem ducimus id recusandae nostrum qui enim eius rem consectetur voluptatem. Et dignissimos unde aut fugit quaerat est aperiam velit ut maiores laborum! Sit esse velit est ipsam quidem non saepe ratione et itaque quod hic atque possimus. Qui quia repellendus sit impedit animi qui accusamus quia sed quos recusandae est mollitia obcaecati est omnis sequi?\n" +
                "\n" +
                "Est maxime perspiciatis eos odit nulla ab modi obcaecati. Nam amet assumenda sed aliquam nesciunt et dolorem velit. Non numquam ducimus ex aliquam incidunt id quam sequi id explicabo assumenda in fugiat ratione.",
        "fechaDeCreacion" to "14/1/2023",
        "categoria" to "Noticias Gremiales",
        "imagen" to "Noticia1.png",
    )

    val noticia2 = hashMapOf(
        "ID" to 2,
        "titulo" to "Situacion problematica en el Sanatorio Fueguino",
        "contenido" to "Lorem ipsum dolor sit amet. Est rerum fuga id ipsum vitae aut quaerat rerum ut tempore rerum et vitae inventore quo provident facilis ut consequuntur ratione. Et architecto autem et eveniet odit aut fuga dolorum et pariatur quisquam est amet commodi et animi perferendis. Sit officia ipsum qui facere reprehenderit ab internos officia. Et aspernatur culpa et repudiandae quasi et pariatur sequi et dolorum odit ut labore veniam eum delectus recusandae?\n" +
                "\n" +
                "In praesentium omnis vel culpa placeat non praesentium voluptatem sit autem ducimus id recusandae nostrum qui enim eius rem consectetur voluptatem. Et dignissimos unde aut fugit quaerat est aperiam velit ut maiores laborum! Sit esse velit est ipsam quidem non saepe ratione et itaque quod hic atque possimus. Qui quia repellendus sit impedit animi qui accusamus quia sed quos recusandae est mollitia obcaecati est omnis sequi?\n" +
                "\n" +
                "Est maxime perspiciatis eos odit nulla ab modi obcaecati. Nam amet assumenda sed aliquam nesciunt et dolorem velit. Non numquam ducimus ex aliquam incidunt id quam sequi id explicabo assumenda in fugiat ratione.",
        "fechaDeCreacion" to "15/1/2023",
        "categoria" to "Noticias Internacionales",
        "imagen" to "Noticia2.png",
    )

    val noticia3 = hashMapOf(
        "ID" to 3,
        "titulo" to "Conflicto con planta x por despido sin justificar",
        "contenido" to "Lorem ipsum dolor sit amet. Est rerum fuga id ipsum vitae aut quaerat rerum ut tempore rerum et vitae inventore quo provident facilis ut consequuntur ratione. Et architecto autem et eveniet odit aut fuga dolorum et pariatur quisquam est amet commodi et animi perferendis. Sit officia ipsum qui facere reprehenderit ab internos officia. Et aspernatur culpa et repudiandae quasi et pariatur sequi et dolorum odit ut labore veniam eum delectus recusandae?\n" +
                "\n" +
                "In praesentium omnis vel culpa placeat non praesentium voluptatem sit autem ducimus id recusandae nostrum qui enim eius rem consectetur voluptatem. Et dignissimos unde aut fugit quaerat est aperiam velit ut maiores laborum! Sit esse velit est ipsam quidem non saepe ratione et itaque quod hic atque possimus. Qui quia repellendus sit impedit animi qui accusamus quia sed quos recusandae est mollitia obcaecati est omnis sequi?\n" +
                "\n" +
                "Est maxime perspiciatis eos odit nulla ab modi obcaecati. Nam amet assumenda sed aliquam nesciunt et dolorem velit. Non numquam ducimus ex aliquam incidunt id quam sequi id explicabo assumenda in fugiat ratione.",
        "fechaDeCreacion" to "16/1/2023",
        "categoria" to "Actividades",
        "imagen" to "Noticia3.png",
    )

    // Noticia 1
    db.collection("Noticia").document(noticia1.get("ID").toString()).set(noticia1)
        .addOnSuccessListener {
            Log.d(TAG, "Noticia cargado con la ID: ${noticia1.get("ID")}")
        }
        .addOnFailureListener { e ->
            Log.w(TAG, "Error adding document", e)
        }

    // Noticia 2
    db.collection("Noticia").document(noticia2.get("ID").toString()).set(noticia2)
        .addOnSuccessListener {
            Log.d(TAG, "Noticia cargado con la ID: ${noticia2.get("ID")}")
        }
        .addOnFailureListener { e ->
            Log.w(TAG, "Error adding document", e)
        }

    // Noticia 3
    db.collection("Noticia").document(noticia3.get("ID").toString()).set(noticia3)
        .addOnSuccessListener {
            Log.d(TAG, "Noticia cargado con la ID: ${noticia3.get("ID")}")
        }
        .addOnFailureListener { e ->
            Log.w(TAG, "Error adding document", e)
        }

}// Fin de la funcion<


fun guardarTEST() {
    val user = hashMapOf(
        "first" to "Ada",
        "last" to "Lovelace",
        "born" to 1815
    )

// Add a new document with a generated ID
    db.collection("users")
        .add(user)
        .addOnSuccessListener { documentReference ->
            Log.d(TAG, "DocumentSnapshot added with ID: ${documentReference.id}")
        }
        .addOnFailureListener { e ->
            Log.w(TAG, "Error adding document", e)
        }
}