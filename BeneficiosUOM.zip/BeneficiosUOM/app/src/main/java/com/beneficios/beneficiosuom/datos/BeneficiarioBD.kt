package com.beneficios.beneficiosuom.datos

// USUARIOS   ------------------------------------------------------
data class BeneficiarioBD(
    var ID: Int,
    var nombreCompleto: String,
    var DNI: Int,
    var fabrica: String,
    var estado: Boolean?,
    var notificaciones: ArrayList<NotificacionBD>
) {
    constructor() : this(0,"",0,"",false, arrayListOf(NotificacionBD(0,"","")))
}

// ADMINISTRADOR   ------------------------------------------------------
data class AdminBD(
    var DNI: Int,
) {
    constructor() : this(0)
}