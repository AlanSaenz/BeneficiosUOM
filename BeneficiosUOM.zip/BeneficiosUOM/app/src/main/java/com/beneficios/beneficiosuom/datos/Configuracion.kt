package com.beneficios.beneficiosuom.datos

data class Configuracion(
    var titulo: String,
    var descripcion: String,
    var direccionPantalla: String
) {
    constructor() : this("","","")
}
