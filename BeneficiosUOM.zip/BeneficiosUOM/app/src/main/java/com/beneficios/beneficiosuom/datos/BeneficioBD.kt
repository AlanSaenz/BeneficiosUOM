package com.beneficios.beneficiosuom.datos

// BENEFICIO   ----------------------------------------------------
data class BeneficioBD(
    var ID: Int,
    var lugar: String,
    var descripcionCompleta: String,
    var descripcionCorta: String,
    var ubicacion: String,
    var telefono: String,
    var horario: String,
    var imagen: String,
    var categoria: String,
    var descuentoSINO: Boolean,
    var tarifaSINO: Boolean,
) {
    constructor() : this(0,"","","","","","","","",false,false)
}
