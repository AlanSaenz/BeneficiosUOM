package com.beneficios.beneficiosuom.interfaz

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.beneficios.beneficiosuom.R
import com.beneficios.beneficiosuom.datos.BeneficioBD
import com.beneficios.beneficiosuom.navegacion.PantallaApp

// LISTA DEFINITIVA -------------------------------------------------------------------------------
//Determinar un String que recibe la fun para el titulo de cada lista, tambien recibe una lista --- OK
//Hacer una funciono que determine que lista va a recibir. Osea, hacer que tome un string que sea la categoria y haga una nueva lista a partir de ello. Que recibe esta fun. --- OK
@Composable
fun ListaDefinitiva(text:String?, lista: List<BeneficioBD>, navController: NavController, mapaNombreImagen: Map<String, String>, fuenteLetra:FontFamily) {
    val categoriaPantalla = text
    
    ListaDeBeneficios(lista = (tomarLista(listaCompleta = lista as MutableList<BeneficioBD>, categoria = categoriaPantalla)),navController, mapaNombreImagen, fuenteLetra)

    Toolbar2(titulo = categoriaPantalla, fondo = Color.White, letra = Color.Black,fuente = fuenteLetra, navController)
}

@Composable
fun tomarLista(listaCompleta: MutableList<BeneficioBD>, categoria: String?):List<BeneficioBD>{
    val newList:MutableList<BeneficioBD> = mutableListOf()

    for (BeneficioBD in listaCompleta){
        if (categoria == BeneficioBD.categoria){
            newList.add(BeneficioBD)
        }
    }
    return newList
}


// LISTA DE BENEFICIOS -------------------------------------------------------------------------------
@Composable
fun ListaDeBeneficios(lista: List<BeneficioBD>, navController: NavController, mapaNombreImagen: Map<String, String>, fuenteLetra:FontFamily,modifier: Modifier = Modifier) {

    LazyColumn {
        item { Spacer(modifier = Modifier.padding(top = 80.dp)) }
        items(lista) { BeneficioBD ->
            listaCarta(objetoDeLista = BeneficioBD, navController, mapaNombreImagen, fuenteLetra)
        }
    }
}

// CADA OBJETO DE LISTA -------------------------------------------------------------------------------
@Composable
fun listaCarta(objetoDeLista: BeneficioBD, navController: NavController, mapaNombreImagen: Map<String, String>, fuenteLetra:FontFamily,modifier: Modifier = Modifier) {

    Button(
        onClick = { navController.navigate(route = PantallaApp.Detalle.ruta  + objetoDeLista.ID) },
        colors = ButtonDefaults.buttonColors(backgroundColor = Color.White),
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .border(border = BorderStroke(3.dp, Color.Black), shape = RoundedCornerShape(25.dp))
    ) {


        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .size(width = 150.dp, height = 160.dp)
                .padding(2.dp)
        ) {

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.size(width = 200.dp, height = 180.dp)
            ) {
                Text(
                    text = objetoDeLista.lugar,
                    textAlign = TextAlign.Center,
                    fontSize = 20.sp,
                    fontFamily = fuenteLetra,
                    style = MaterialTheme.typography.h6,
                    modifier = Modifier
                )

                AsyncImage(
                    model = mapaNombreImagen.get(objetoDeLista.imagen),
                    contentDescription = null,
                    error = painterResource(id = R.drawable.imagenerror),
                    placeholder = painterResource(id = R.drawable.imagenerror),
                    modifier = Modifier
                        .padding(top = 10.dp)
                        .width(200.dp)
                        .height(100.dp)
                        .clip(RoundedCornerShape(25.dp)),
                    contentScale = ContentScale.Crop
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.size(width = 200.dp, height = 180.dp)
            ) {
                Text(
                    text = (objetoDeLista.descripcionCorta),
                    textAlign = TextAlign.Center,
                    fontSize = 15.sp,
                    fontFamily = fuenteLetra,
                    style = MaterialTheme.typography.h6,
                    modifier = Modifier
                        .fillMaxHeight()
                        .wrapContentHeight(Alignment.CenterVertically)
                        .padding(start = 5.dp)
                )
            }


        }

    }
}