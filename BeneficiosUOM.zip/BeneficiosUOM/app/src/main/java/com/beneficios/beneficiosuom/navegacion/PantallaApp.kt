package com.beneficios.beneficiosuom.navegacion


sealed class PantallaApp(val ruta: String){
    object Splash: PantallaApp("splash")
    object Inicio: PantallaApp("inicio")
    object Comercio: PantallaApp("comercio")
    object Turismo: PantallaApp("turismo")
    object Prensa: PantallaApp("prensa")
    object Lista: PantallaApp("lista")
    object Detalle: PantallaApp("detalle")
    object Noticia: PantallaApp("Noticia")
    object Credencial: PantallaApp("credencial")
    object NumerosUtiles: PantallaApp("numerosutiles")
    object DNI: PantallaApp("DNI")
    object ErrorDNI: PantallaApp("errorDNI")
    object Notificacion:PantallaApp("notificacion")
    object Configuracion:PantallaApp("configuracion")
    object NotificacionTodos:PantallaApp("notificaciontodos")
    object ContraAdmin:PantallaApp("contraadmin")
}
