package com.beneficios.beneficiosuom.interfaz

import android.content.ContentValues.TAG
import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.beneficios.beneficiosuom.R
import com.beneficios.beneficiosuom.datos.BeneficiarioBD
import com.beneficios.beneficiosuom.datos.NotificacionBD
import com.beneficios.beneficiosuom.navegacion.PantallaApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import androidx.compose.material.Text as text

// NOTIFICACIONES ------------------------------------------------------------------------------

@Composable
fun notificaciones(
    listaUsuarios: List<BeneficiarioBD>,
    usuario: BeneficiarioBD,
    navController: NavController,
    fuenteLetra: FontFamily,
    imgFondo:String
) {

    val fondoEngranaje = painterResource(id = R.drawable.fondonewfinal)

    AsyncImage(
        model = imgFondo,
        contentDescription = null,
        error = fondoEngranaje,
        placeholder = painterResource(id = R.drawable.imagencarga),
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(),
        contentScale = ContentScale.FillWidth
    )

    LazyColumn {

        item {
            Toolbar3(
                titulo = "Notificaciones",
                fondo = Color.White,
                letra = Color.Black,
                fuente = fuenteLetra,
                navController
            )
        }

        if (usuario.notificaciones.isEmpty()) {

            item {
                text(
                    text = "No posee notificaciones",
                    textAlign = TextAlign.Center,
                    fontSize = 25.sp,
                    fontFamily = fuenteLetra,
                    color = Color.Black,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 15.dp)
                )
            }

        } else {
            items(usuario.notificaciones) {
                notificacionCarta(
                    Noti = it,
                    fuenteLetra = fuenteLetra,
                    usuario = usuario,
                    navController = navController
                )
            }
        }
    }

}

// NOTIFICACIONES CARTA ------------------------------------------------------------------------------

@Composable
fun notificacionCarta(
    Noti: NotificacionBD,
    fuenteLetra: FontFamily,
    usuario: BeneficiarioBD,
    navController: NavController
) {

    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth(1f)
            .padding(10.dp)
            .border(border = BorderStroke(3.dp, Color.Black), shape = RoundedCornerShape(25.dp))

    ) {

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth(0.87f)
                .padding(5.dp)
                //.border(border = BorderStroke(3.dp, Color.Black), shape = RoundedCornerShape(25.dp))
        ) {


            text(
                text = Noti.titulo,
                textAlign = TextAlign.Center,
                fontSize = 25.sp,
                fontFamily = fuenteLetra,
                color = Color.Black,
                style = MaterialTheme.typography.h6,
                modifier = Modifier.padding(top = 5.dp)
            )

            text(
                text = Noti.descripcion,
                textAlign = TextAlign.Center,
                fontSize = 17.sp,
                fontFamily = fuenteLetra,
                color = Color.Black,
                fontWeight = FontWeight.Black,
                style = MaterialTheme.typography.h6,
                modifier = Modifier.padding(vertical = 10.dp, horizontal = 10.dp)
            )

        }

        Image(
            painter = painterResource(id = R.drawable.eliminaricono),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(35.dp)
                .clickable {
                    eliminarNotificacion(user = usuario, IDnoti = Noti.id)
                    navController.popBackStack()
                    navController.navigate(route = PantallaApp.Notificacion.ruta)
                }
        )
        
        Spacer(modifier = Modifier.width(5.dp))

    }
}


//-------------------------------------------------------------------------------------------------------------------------------------------------------

// ENVIAR NOTIFICACION A UN USUARIO
fun notificacionTodos(user: BeneficiarioBD, titulo: String, descripcion: String) {

    val db = FirebaseFirestore.getInstance()

    val ultimoid = user.notificaciones.lastIndex + 1
    val datoExtra = NotificacionBD(ultimoid, titulo, descripcion)
    val listaNoti = user.notificaciones

    listaNoti.add(datoExtra)

    var data = hashMapOf(
        "notificaciones" to listaNoti
    )

    db.collection("Usuario").document(user.ID.toString())
        .set(data, SetOptions.merge())
        .addOnSuccessListener { Log.d(TAG, "DocumentSnapshot successfully!") }
        .addOnFailureListener { e -> Log.w(TAG, "Error writing document", e) }

}


// CREAR NOTIFICACION EN BD A TODOS LOS USUARIOS
fun crearNotificacionTodos(listaUsuarios: List<BeneficiarioBD>) {

    val db = FirebaseFirestore.getInstance()

    listaUsuarios.forEach { user ->

        var data = hashMapOf(
            "notificaciones" to mutableListOf<NotificacionBD>()
        )

        db.collection("Usuario").document(user.ID.toString())
            .set(data, SetOptions.merge())
            .addOnSuccessListener { Log.d(TAG, "Actualizacion correcta successfully!") }
            .addOnFailureListener { e -> Log.w(TAG, "Error writing document", e) }

        Log.d(TAG, "Completado para el usuario ${user.ID}!!!")
    } // Fin del forEach

}

// ELIMINAR NOTIFICACION EN BD DE UN USUARIO
fun eliminarNotificacion(user: BeneficiarioBD, IDnoti: Int) {

    val db = FirebaseFirestore.getInstance()
    val listaNoti = user.notificaciones
    var notiEliminar = NotificacionBD()


    listaNoti.forEach {
        if (IDnoti == it.id) {
            notiEliminar = it
        }
    }

    if (notiEliminar != NotificacionBD(0, "", "")) {

        listaNoti.remove(notiEliminar)

    var data = hashMapOf(
        "notificaciones" to listaNoti
    )

    db.collection("Usuario").document(user.ID.toString())
        .set(data, SetOptions.merge())
        .addOnSuccessListener { Log.d(TAG, "Actualizacion correcta successfully!") }
        .addOnFailureListener { e -> Log.w(TAG, "Error writing document", e) }

    Log.d(TAG, "Completado la eliminacion de la Noti $IDnoti para el usuario ${user.ID}!!!")

    } else {
        Log.d(TAG, "No se pudo eliminar Notificacion ${notiEliminar} con el ID = $IDnoti!")
    }

}


// ------------------------------------------------------------- PRUEBAS ----------------------------------------------------------------------------------

// CREAR NOTIFICACION A TODOS LOS USUARIOS ------------------------------------------------------------------------------ TEST
fun crearNotificacionTodosTest(user: BeneficiarioBD) {
    Log.d(TAG, "Se ingreso a la funcion de Notificacion ♣♣♣♣♣")
    Log.d(TAG, "♣♣♣♣♣ - usuario = ${user.DNI}")

    val db = FirebaseFirestore.getInstance()

    var usuario = hashMapOf(
        "ID" to user.ID,
        "DNI" to user.DNI,
        "estado" to user.estado,
        "fabrica" to user.fabrica,
        "nombreCompleto" to user.nombreCompleto,
        "notificaciones" to mutableListOf<NotificacionBD>(
            NotificacionBD(0, "", ""),
            NotificacionBD(1, "Test2", "Texto descriptivo")
        ),
    )

    db.collection("Usuario").document(user.ID.toString())
        .set(usuario)
        .addOnSuccessListener { Log.d(TAG, "DocumentSnapshot successfully!") }
        .addOnFailureListener { e -> Log.w(TAG, "Error writing document", e) }

    Log.d(TAG, "Se finalizo a la funcion de Notificacion ♣♣♣♣♣2")
}


// CREAR NOTIFICACION A TODOS LOS USUARIOS ------------------------------------------------------------------------------ TEST 2
fun crearNotificacionTodosTest2(user: BeneficiarioBD) {

    val db = FirebaseFirestore.getInstance()

    val ultimoid = user.notificaciones.lastIndex + 1
    val datoExtra = NotificacionBD(ultimoid, "Test3", "Texto descriptivo")
    val listaNoti = user.notificaciones

    listaNoti.add(datoExtra)

    var data = hashMapOf(
        "notificaciones" to listaNoti
    )

    db.collection("Usuario").document(user.ID.toString())
        .set(data, SetOptions.merge())
        .addOnSuccessListener { Log.d(TAG, "DocumentSnapshot successfully!") }
        .addOnFailureListener { e -> Log.w(TAG, "Error writing document", e) }

}


// CREAR NOTIFICACION A TODOS LOS USUARIOS ------------------------------------------------------------------------------ TEST 3
fun crearNotificacionTodosTest3(user: BeneficiarioBD) {

    val db = FirebaseFirestore.getInstance()


    var data = hashMapOf(
        "notificaciones" to mutableListOf<NotificacionBD>()
    )

    db.collection("Usuario").document(user.ID.toString())
        .set(data, SetOptions.merge())
        .addOnSuccessListener { Log.d(TAG, "DocumentSnapshot successfully!") }
        .addOnFailureListener { e -> Log.w(TAG, "Error writing document", e) }

}