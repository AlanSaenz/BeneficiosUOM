package com.beneficios.beneficiosuom.interfaz

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.beneficios.beneficiosuom.datos.NoticiaBD
import okhttp3.internal.notify
import kotlin.math.roundToInt


@Composable
public fun tomarObjetoDeListaNoticia(id: Int?, listaNoticias: List<NoticiaBD>): NoticiaBD {
    var elObjeto: NoticiaBD = NoticiaBD(
        0, "NADA", "NADA", "NADA", "NADA", "", ""
    )

    for (NoticiaBD in listaNoticias) {
        if (id == NoticiaBD.ID) {
            elObjeto = NoticiaBD
        }
    }
    return elObjeto
}


@Composable
fun DetalleNoticia(
    numero: Int?,
    listaCompleta: List<NoticiaBD>,
    navController: NavController,
    mapaNombreImagen2: Map<String, String>,
    colorLetra: Color,
    colorMarco: Color,
    colorFondo: Color,
    fuenteLetra: androidx.compose.ui.text.font.FontFamily
) {
    val noticia: NoticiaBD = tomarObjetoDeListaNoticia(numero, listaCompleta)

    val linkNoticia = remember { Intent(Intent.ACTION_VIEW, Uri.parse(noticia.link)) }

    val context = LocalContext.current

    var isExpanded by remember { mutableStateOf(false) }
    var scale by remember { mutableStateOf(1f) }
    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }

    LazyColumn(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top,
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight()
    ) {

        item {
            Toolbar2(
                titulo = noticia.categoria,
                fondo = Color.Black,
                letra = Color.White,
                fuente = fuenteLetra,
                navController
            )
        }

        item { Toolbar(titulo = "UOM Seccional Rio Grande", fuente = fuenteLetra) }

        item {
            Spacer(modifier = Modifier.height(10.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
            ) {

                AsyncImage(
                    model = mapaNombreImagen2.get(noticia.imagen),
                    contentDescription = null,
                    contentScale = ContentScale.FillWidth,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 5.dp)
                            /*
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, gestureZoom, _ ->
                                // Detectar gestos de pan (desplazamiento) y zoom
                                scale *= gestureZoom
                                offsetX += pan.x
                                offsetY += pan.y
                            }
                        }
                        .scale(scale)
                        .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }

                             */
                        .clickable {
                            //scale = 1f
                            //offsetX = 0f
                            //offsetY = 0f
                            isExpanded = !isExpanded
                            // Al hacer clic, cambiamos el valor de isExpanded
                        }
                )


                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = noticia.titulo,
                    fontFamily = fuenteLetra,
                    color = colorLetra,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(CenterHorizontally)
                        .padding(horizontal = 12.dp)
                )
            }

        }

        item {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
            ) {

                Text(
                    text = noticia.fechaDeCreacion,
                    fontFamily = fuenteLetra,
                    color = colorLetra,
                    modifier = Modifier
                        .align(Alignment.Start)
                        .padding(start = 4.dp)
                )

                Spacer(modifier = Modifier.height(2.dp))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.CenterHorizontally)
                            .padding(2.dp)
                            .background(colorFondo)
                            .border(
                                border = BorderStroke(1.dp, colorMarco),
                                shape = CutCornerShape(1.dp)
                            )
                    ) {
                        if (noticia.link != "") {

                            Spacer(modifier = Modifier.height(5.dp))

                            Text(
                                text = noticia.link,
                                fontFamily = fuenteLetra,
                                color = Color.Blue,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .align(CenterHorizontally)
                                    .clickable { context.startActivity(linkNoticia) }
                                    .padding(top = 8.dp)
                            )

                        }

                        Spacer(modifier = Modifier.height(5.dp))

                        Text(
                            text = noticia.contenido,
                            fontFamily = fuenteLetra,
                            color = colorLetra,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 9.dp, horizontal = 10.dp)
                        )
                    }

            }
        }
    }// Fin colum principal
    
    Column(Modifier.fillMaxSize()) {
        if (isExpanded) {
            // Si isExpanded es verdadero, mostrar la imagen a pantalla completa
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .clickable {
                        scale = 1f
                        offsetX = 0f
                        offsetY = 0f
                        isExpanded = !isExpanded
                    }
                    .pointerInput(Unit) {
                        detectTapGestures(onDoubleTap = {
                            // Al hacer doble clic, volver a la vista original
                            scale = 1f
                            offsetX = 0f
                            offsetY = 0f
                        })
                    }
            ) {
                // Agregar la imagen en la vista ampliada
                AsyncImage(
                    model = mapaNombreImagen2.get(noticia.imagen),
                    contentDescription = null,
                    contentScale = ContentScale.FillWidth,
                    modifier = Modifier
                        .fillMaxWidth()
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, gestureZoom, _ ->
                                // Detectar gestos de pan (desplazamiento) y zoom
                                scale *= gestureZoom
                                offsetX += pan.x
                                offsetY += pan.y
                            }
                        }
                        .scale(scale)
                        .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                        .clickable {
                            scale = 1f
                            offsetX = 0f
                            offsetY = 0f
                            isExpanded = !isExpanded
                        }
                )
            }
        }
    }
}