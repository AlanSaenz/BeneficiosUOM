package com.beneficios.beneficiosuom.interfaz

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.beneficios.beneficiosuom.R
import com.beneficios.beneficiosuom.datos.NumerosUtilesBD

@Composable
fun NumerosUtiles(lista: List<NumerosUtilesBD>, navController: NavController, colorLetra:Color, colorMarco:Color,fuenteLetra:androidx.compose.ui.text.font.FontFamily) {

    val fondoEngranaje = painterResource(id = R.drawable.fondonewfinal)
    Image(
        painter = fondoEngranaje,
        contentDescription = null,
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(),
        contentScale = ContentScale.FillWidth
    )

    ListaDeNumerosUtiles(lista = lista, colorLetra = colorLetra, colorMarco = colorMarco, fuenteLetra = fuenteLetra)
    ToolbarNumerosUtiles(titulo = "Numeros Utiles", fondo = Color.Black, letra = Color.White,fuente = fuenteLetra, navController)

}

@Composable
fun ListaDeNumerosUtiles(lista: List<NumerosUtilesBD>, modifier: Modifier = Modifier, colorLetra:Color, colorMarco:Color,fuenteLetra:androidx.compose.ui.text.font.FontFamily) {

    LazyColumn {
        item { Spacer(modifier = Modifier.padding(top = 70.dp)) }

        items(lista) { numero ->
            NumerosUtilesCarta(objetoDeLista = numero, colorLetra = colorLetra, colorMarco = colorMarco, fuenteLetra = fuenteLetra)
        }
    }
}

@Composable
fun NumerosUtilesCarta(objetoDeLista: NumerosUtilesBD, colorLetra:Color, colorMarco:Color,fuenteLetra:androidx.compose.ui.text.font.FontFamily, modifier: Modifier = Modifier) {
    var telefono = painterResource(id = R.drawable.telefono_negro)

    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth(1f)
            .height(140.dp)
            .padding(8.dp)
            .border(border = BorderStroke(3.dp, colorMarco), shape = RoundedCornerShape(25.dp))
    ) {

        Spacer(modifier = Modifier.width(40.dp))
        
        Image(
            painter = telefono,
            contentDescription = null,
            modifier = Modifier
                .padding(top = 15.dp, end = 15.dp, bottom = 15.dp)
                .size(65.dp),
            contentScale = ContentScale.Crop
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.size(width = 300.dp, height = 170.dp)
        ) {
            Text(
                text = objetoDeLista.nombre,
                textAlign = TextAlign.Center,
                fontSize = 22.sp,
                fontFamily = fuenteLetra,
                color = colorLetra,
                style = MaterialTheme.typography.h6,
                modifier = Modifier.padding(vertical = 5.dp)
            )

            objetoDeLista.telefono?.let {
                Text(
                    text = it,
                    textAlign = TextAlign.Center,
                    fontSize = 18.sp,
                    fontFamily = fuenteLetra,
                    color = colorLetra,
                    fontWeight = FontWeight.Black,
                    style = MaterialTheme.typography.h6,
                    modifier = Modifier.padding(vertical = 1.dp)
                )
            }

            objetoDeLista.direccion?.let {
                Text(
                    text = it,
                    textAlign = TextAlign.Center,
                    fontSize = 18.sp,
                    fontFamily = fuenteLetra,
                    color = colorLetra,
                    fontWeight = FontWeight.Black,
                    style = MaterialTheme.typography.h6,
                    modifier = Modifier.padding(vertical = 1.dp)
                )
            }
        }
    }

}// fin