package com.beneficios.beneficiosuom.interfaz

import android.content.ContentValues
import android.util.Log
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.beneficios.beneficiosuom.R
import com.beneficios.beneficiosuom.navegacion.PantallaApp

@Composable
fun contraseñaAdminPantalla(navController: NavController,contraBD:String,fuenteLetra: androidx.compose.ui.text.font.FontFamily){

    var contraEscrita by remember { mutableStateOf("") }
    var showDialog by remember { mutableStateOf(false) }

    Image(
        painter = painterResource(id = R.drawable.fondoblur),
        contentDescription = null,
        modifier = Modifier.fillMaxSize(),
        contentScale = ContentScale.FillWidth
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight()
    ) {

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .height(250.dp)
                .background(Color.White)
                .border(
                    border = BorderStroke(3.dp, Color.Black)
                )
        ) {

            Text(
                text = "Ingrese la contraseña de Administradores",
                fontSize = 25.sp,
                fontFamily = fuenteLetra,
                color = Color.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))

            TextField(
                value = contraEscrita.toString(),
                onValueChange = { contraEscrita = it.toString() },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                label = { Text("Ingresa contraseña") },
                modifier = Modifier
                    .background(Color.White)
                    .border(
                        border = BorderStroke(3.dp, Color.Black)
                    )
            )

            Spacer(modifier = Modifier.height(20.dp))

            Text(text = "INGRESAR",
                color = Color.Black,
                fontSize = 20.sp,
                fontFamily = fuenteLetra,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth(0.7f)
                    .height(60.dp)
                    .border(border = BorderStroke(3.dp, Color.Black))
                    .padding(top = 17.dp)
                    .clickable {
                        if (contraEscrita == contraBD){

                            navController.navigate(route = PantallaApp.Configuracion.ruta)

                        } else if (contraEscrita != contraBD){

                            showDialog = true

                        }
                    }
            )
        }

        if (showDialog) {
            AlertDialog(
                onDismissRequest = { showDialog = false },
                title = { Text("Error al ingresar la contraseña") },
                text = { Text("Se ingreso una contraseña incorrecta. Intentelo de nuevo.") },
                confirmButton = {
                    Button(
                        onClick = { showDialog = false },
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color.White),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(0.dp, 0.dp, 12.dp, 12.dp)
                    ) {
                        Text(
                            "Aceptar",
                            color = Color.Black
                        )
                    }
                },
                modifier = Modifier.padding(16.dp)
            )
        }

    }

}